# RAG Semantic Bundle (repo-safe)

- Repo root: `/Users/e/Documents/MotivicCohomology/GitLocal/EdgeLorD`
- Git HEAD: `6ecfa20952749bb57cb096dacccd1eabbb4cdec9` (dirty)
- Generated (UTC): `2026-02-08T15:50:56.378803+00:00`
- Mode: `overview`

## Audit
- considered (git paths): **88**
- included: **81**
- skipped: not-allowed=7, excluded=0, missing=0, too-large=0
- budgets: max_files=1000000, max_file_bytes=5000000, max_output_kb=200000

## Cargo overview

### `Cargo.toml`
- package: **edgelord-lsp** 0.1.0
- deps (15): tokio, tower-lsp, serde, serde_json, thiserror, source_span, codeswitch, new_surface_syntax, sniper_db, async-trait, crc32fast, tantivy, tcb_core, sha2, hex

## Rust semantics (lossy)

- Included Rust files: **59**
- include_private=1; brief=0

### `src/client_sink.rs`
- uses:
  - `async_trait::async_trait`
  - `tower_lsp::Client`
- items:
  - (pub trait) `pub trait ClientSink: Send + Sync + 'static`
  - (priv fn) `async fn log_message(&self, message_type: MessageType, message: String);`
  - (priv fn) `async fn publish_diagnostics(&self, uri: Url, diagnostics: Vec<Diagnostic>, version: Option<i32>);`
  - (pub struct) `pub struct RealClientSink`
  - (priv impl) `impl RealClientSink`
  - (pub fn) `pub fn new(client: Client) -> Self`
  - (priv impl) `impl ClientSink for RealClientSink`
  - (priv fn) `async fn log_message(&self, message_type: MessageType, message: String)`
  - (priv fn) `async fn publish_diagnostics(&self, uri: Url, diagnostics: Vec<Diagnostic>, version: Option<i32>)`

### `src/diff/engine.rs`
- uses:
  - `std::collections::{BTreeMap, BTreeSet}`
  - `new_surface_syntax::proof_state::{ProofState, MorMetaId, GoalStatus as KernelGoalStatus}`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
  - `crate::goals_panel::{GoalDelta, GoalChangeKind, GoalStatus}`
- items:
  - (pub fn) `pub fn compute_diff(` — Computes the semantic difference between two proof states.
  - (priv fn) `fn map_status(status: &KernelGoalStatus) -> GoalStatus`
  - (priv fn) `fn get_blockers(status: &KernelGoalStatus, index: &GoalsPanelIndex) -> BTreeSet<String>`

### `src/diff/mod.rs`
- modules:
  - `pub mod engine;`

### `src/document.rs`
- uses:
  - `std::{cmp::Ordering, collections::BTreeSet}`
  - `tower_lsp::lsp_types::TextDocumentContentChangeEvent`
- items:
  - (pub struct) `pub struct ByteSpan`
  - (priv impl) `impl ByteSpan`
  - (pub fn) `pub fn new(start: usize, end: usize) -> Self`
  - (pub fn) `pub fn len(&self) -> usize`
  - (pub fn) `pub fn contains_offset(&self, offset: usize) -> bool`
  - (pub struct) `pub struct ParseDiagnostic`
  - (priv struct) `struct CstNode`
  - (pub struct) `pub struct ParsedDocument`
  - (pub struct) `pub struct Goal`
  - (pub enum) `pub enum BindingKind`
  - (pub struct) `pub struct Binding`
  - (pub struct) `pub struct GoalInlayHint`
  - (priv impl) `impl ParsedDocument`
  - (pub fn) `pub fn parse(text: String) -> Self`
  - (pub fn) `pub fn selection_chain_for_offset(&self, offset: usize) -> Vec<ByteSpan>`
  - (pub fn) `pub fn goal_at_offset(&self, offset: usize) -> Option<&Goal>`
  - (pub fn) `pub fn goal_inlay_hints_in_range(&self, range: ByteSpan) -> Vec<GoalInlayHint>`
  - (priv fn) `fn node_order(nodes: &[CstNode]) -> impl FnMut(&usize, &usize) -> Ordering + '_`
  - (priv fn) `fn add_expr_node(nodes: &mut Vec<CstNode>, parent: usize, expr: &SExpr) -> usize`
  - (priv fn) `fn parse_error_span(err: &ParseError, text_len: usize) -> ByteSpan`
  - (priv fn) `fn extract_goals(forms: &[SExpr]) -> Vec<Goal>`
  - (priv fn) `fn collect_holes_in_expr(`
  - (priv fn) `fn hole_form_name(items: &[SExpr]) -> Option<String>`
  - (priv fn) `fn collect_top_level_bindings(form: &SExpr, context: &mut Vec<Binding>)`
  - (priv fn) `fn goal_id(start: usize, end: usize, name: Option<&str>) -> String`
  - (priv fn) `fn spans_intersect(a: ByteSpan, b: ByteSpan) -> bool`
  - (priv fn) `fn goal_label(goal: &Goal, text: &str) -> String`
  - (priv fn) `fn let_bindings(items: &[SExpr]) -> Option<Vec<Binding>>`
  - (priv fn) `fn merged_context(local_frames: &[Vec<Binding>], top_level_bindings: &[Binding]) -> Vec<Binding>`
  - (pub fn) `pub fn position_to_offset(text: &str, position: tower_lsp::lsp_types::Position) -> usize`
  - (pub fn) `pub fn offset_to_position(text: &str, offset: usize) -> tower_lsp::lsp_types::Position`
  - (pub fn) `pub fn apply_content_changes(text: &str, changes: &[TextDocumentContentChangeEvent]) -> String`
  - (pub fn) `pub fn selection_chain_is_well_formed(chain: &[ByteSpan]) -> bool`
  - (pub fn) `pub fn top_level_symbols(text: &str) -> Vec<(String, ByteSpan)>`

### `src/edgelord_pretty_ctx.rs`
- uses:
  - `new_surface_syntax::diagnostics::pretty::{PrettyCtx, PrettyPrinter, PrettyDialect, PrettyLimits, PrinterRegistry, PrinterKey}`
  - `new_surface_syntax::diagnostics::DiagnosticContext`
  - `new_surface_syntax::proof_state::ProofState`
  - `tower_lsp::lsp_types::Url`
- items:
  - (pub struct) `pub struct EdgeLordPrettyCtx<'a>` — Ephemeral pretty-printing context for LSP requests. **Lifetime**: Created per hover/inlay/diagnostic request, discarded after. **Design**: Borrowed wrapper avoiding copies of large objects.
  - (pub fn) `pub fn new(`
  - (pub fn) `pub fn document_uri(&self) -> &'a Url`
  - (priv fn) `fn printer(&self) -> &dyn PrettyPrinter`
  - (priv fn) `fn proof(&self) -> &ProofState`
  - (priv fn) `fn files(&self) -> &DiagnosticContext<'_>`
  - (priv fn) `fn limits(&self) -> PrettyLimits`

### `src/explain/alg_blocked.rs`
- uses:
  - `crate::explain::builder::ExplainBuilder`
  - `crate::explain::view::{ExplanationView, ExplanationKind, ExplainLimits}`
  - `new_surface_syntax::proof_state::{ProofState, GoalStatus, MorMetaId}`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
  - `std::collections::{BTreeSet, HashMap}`
  - `source_span::Span`
- items:
  - (pub fn) `pub fn explain_why_blocked(` — Explain why a goal is blocked: show linear blocker chains for highest impact metas.
  - (priv fn) `fn compute_meta_impact(ps: &ProofState) -> HashMap<MorMetaId, usize>`
  - (priv fn) `fn find_goal_for_meta(ps: &ProofState, meta_id: MorMetaId) -> Option<&new_surface_syntax::proof_state::GoalState>`
  - (priv fn) `fn find_span_for_meta(ps: &ProofState, meta_id: MorMetaId) -> Option<Span>`
  - (priv fn) `fn find_primary_blocker(ps: &ProofState, meta_id: MorMetaId, impact_map: &HashMap<MorMetaId, usize>) -> Option<MorMetaId>`

### `src/explain/alg_goal.rs`
- uses:
  - `crate::explain::builder::ExplainBuilder`
  - `crate::explain::view::{ExplanationView, ExplanationKind, ExplainLimits}`
  - `new_surface_syntax::proof_state::{ProofState, GoalStatus}`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
- items:
  - (pub fn) `pub fn explain_goal(` — Explain what a goal is: its context, target, and direct evidence.
  - (priv fn) `fn find_span_for_meta(ps: &ProofState, meta_id: new_surface_syntax::proof_state::MorMetaId) -> Option<source_span::Span>`

### `src/explain/alg_inconsistent.rs`
- uses:
  - `crate::explain::builder::ExplainBuilder`
  - `crate::explain::view::{ExplanationView, ExplanationKind, ExplainLimits}`
  - `new_surface_syntax::proof_state::{ProofState, GoalStatus}`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
- items:
  - (pub fn) `pub fn explain_why_inconsistent(` — Explain why a goal is inconsistent: show deterministic conflict sets and their origins.
  - (priv const) `const MAX_CONFLICT_SETS: usize = 3;`

### `src/explain/builder.rs`
- uses:
  - `std::collections::{BTreeMap, VecDeque, HashSet}`
  - `source_span::Span`
  - `crate::explain::view::{ExplanationNode, ExplanationKind, ExplanationView, ExplainLimits}`
- items:
  - (pub struct) `pub struct NodeRecord` — Internal record for a node in the arena.
  - (pub struct) `pub struct ExplainBuilder` — Arena-based builder to avoid borrow-check pain and ensure deterministic materialization.
  - (priv impl) `impl ExplainBuilder`
  - (pub fn) `pub fn new(limits: ExplainLimits) -> Self`
  - (pub fn) `pub fn set_root(&mut self, id: String, kind: ExplanationKind, label: String, span: Option<Span>) -> usize`
  - (pub fn) `pub fn add_metadata(&mut self, node_idx: usize, key: String, value: String)`
  - (pub fn) `pub fn add_child(&mut self, parent_idx: usize, id: String, kind: ExplanationKind, label: String, span: Option<Span>) -> Option<usize>` — Add a child to a parent node. Returns Some(child_idx) if added, None if blocked by limits or already visited.
  - (priv fn) `fn set_truncated(&mut self, reason: &str)`
  - (pub fn) `pub fn next_idx(&mut self) -> Option<usize>`
  - (pub fn) `pub fn get_node(&self, idx: usize) -> &NodeRecord`
  - (pub fn) `pub fn build(self) -> ExplanationView` — Build the final ExplanationView. Performs deterministic sorting of children before materializing.
  - (priv fn) `fn materialize_node(&self, idx: usize) -> ExplanationNode`
  - (pub fn) `pub fn truncate_label(label: String, max_chars: usize) -> String`

### `src/explain/mod.rs`
- modules:
  - `pub mod view;`
  - `pub mod builder;`
  - `pub mod alg_goal;`
  - `pub mod alg_blocked;`
  - `pub mod alg_inconsistent;`
- uses:
  - `tower_lsp::jsonrpc::Result`
  - `crate::explain::view::{ExplainRequest, ExplanationView, ExplainTarget, ExplainLimits, ExplanationNode, validate_span}`
  - `crate::proof_session::ProofSession`
  - `std::sync::Arc`
  - `tokio::sync::RwLock`
- items:
  - (pub fn) `pub async fn handle_explain_request(` — Main handler for edgelord/explain requests.
  - (priv fn) `fn enforce_hard_caps(mut limits: ExplainLimits) -> ExplainLimits`
  - (priv const) `const MAX_NODES_CAP: usize = 300;`
  - (priv const) `const MAX_DEPTH_CAP: usize = 50;`
  - (priv const) `const MAX_CHILDREN_CAP: usize = 50;`
  - (priv const) `const MAX_LABEL_CHARS_CAP: usize = 5000;`
  - (priv const) `const MAX_TIMEOUT_MS_CAP: u64 = 1000;`
  - (priv fn) `fn validate_view_spans(node: &mut ExplanationNode, text_len: usize)`

### `src/explain/view.rs`
- uses:
  - `serde::{Serialize, Deserialize}`
  - `tower_lsp::lsp_types::Url`
  - `source_span::Span`
  - `std::collections::BTreeMap`
- items:
  - (pub struct) `pub struct ExplainRequest`
  - (pub enum) `pub enum ExplainTarget`
  - (pub struct) `pub struct ExplainLimits`
  - (priv impl) `impl Default for ExplainLimits`
  - (priv fn) `fn default() -> Self`
  - (pub struct) `pub struct ExplanationView`
  - (pub struct) `pub struct ExplanationNode`
  - (pub enum) `pub enum ExplanationKind`
  - (pub fn) `pub fn validate_span(span: Span, text_len: usize) -> Option<Span>` — Helper to validate spans against text length.

### `src/goals_panel.rs`
- uses:
  - `serde::{Serialize, Deserialize}`
  - `tower_lsp::lsp_types::Range`
- items:
  - (pub struct) `pub struct GoalsPanelResponse`
  - (pub struct) `pub struct GoalPanelItem`
  - (pub enum) `pub enum GoalStatus`
  - (pub struct) `pub struct BlockerInfo`
  - (pub enum) `pub enum GoalChangeKind`
  - (pub struct) `pub struct GoalDelta`

### `src/highlight.rs`
- uses:
  - `tower_lsp::lsp_types::{SemanticToken, SemanticTokenType, SemanticTokenModifier}`
  - `crate::document::ByteSpan`
  - `new_surface_syntax::parser`
  - `new_surface_syntax::syntax::{SExpr, SExprKind, Atom}`
- items:
  - (pub struct) `pub struct HighlightCtx<'a>`
  - (pub enum) `pub enum SymbolRole`
  - (priv impl) `impl SymbolRole`
  - (pub fn) `pub fn to_lsp_type(&self) -> SemanticTokenType`
  - (pub fn) `pub fn modifiers(&self) -> u32`
  - (pub const) `pub const LEGEND_TOKEN_TYPES: &[SemanticTokenType] = &[`
  - (pub const) `pub const LEGEND_TOKEN_MODIFIERS: &[SemanticTokenModifier] = &[`
  - (pub fn) `pub fn tokens_to_lsp_data(text: &str, tokens: &mut [(ByteSpan, SymbolRole)]) -> Vec<SemanticToken>` — Encodes internal tokens to LSP delta format (Absolute -> Relative). Must be sorted by Position.
  - (pub fn) `pub fn compute_layer0_structural(text: &str) -> Vec<(ByteSpan, SymbolRole)>` — Compute Layer 0 structural tokens.
  - (priv fn) `fn traverse_sexpr(expr: &SExpr, out: &mut Vec<(ByteSpan, SymbolRole)>)`
  - (priv fn) `fn handle_special_form_head(expr: &SExpr, role: SymbolRole, out: &mut Vec<(ByteSpan, SymbolRole)>)`
  - (priv fn) `fn scan_fallback(text: &str, out: &mut Vec<(ByteSpan, SymbolRole)>)` — Simple fallback scanner for Layer 0 when parser fails.

### `src/lib.rs`
- modules:
  - `pub mod lsp;`
  - `pub mod document;`
  - `pub mod proof_session;`
  - `pub mod span_conversion;`
  - `pub mod goals_panel;`
  - `pub mod edgelord_pretty_ctx;`
  - `pub mod explain;`
  - `pub mod tactics;`
  - `pub mod diff;`
  - `pub mod proposal;`
  - `pub mod loogle;`
  - `pub mod refute;`
  - `pub mod highlight;`

### `src/loogle/applicability.rs`
- uses:
  - `crate::proposal::{Proposal, ProposalKind, ProposalStatus, EvidenceSummary, ReconstructionPlan}`
  - `super::LoogleResult`
  - `std::collections::HashMap`
  - `sha2::{Sha256, Digest}`
- items:
  - (pub struct) `pub struct ApplicabilityResult` — Applicability engine that checks if a lemma can unify with a goal Result of checking applicability of a lemma to a goal
  - (pub fn) `pub fn check_applicability(` — Check if a lemma result is applicable to a current goal
  - (priv enum) `enum TermStructure` — Lightweight structural representation for unification
  - (priv fn) `fn parse_fingerprint(fp: &str) -> TermStructure` — Parse a fingerprint string into a TermStructure
  - (priv fn) `fn unify_structures(` — Simple first-order unification
  - (priv fn) `fn unify_inner(` — Recursive unification helper
  - (priv fn) `fn compute_confidence(subst: &HashMap<String, TermStructure>) -> f32` — Compute confidence based on substitution complexity
  - (priv fn) `fn structure_complexity(s: &TermStructure) -> usize` — Estimate complexity of a structure
  - (priv fn) `fn format_substitutions(subst: &HashMap<String, TermStructure>) -> String` — Format substitutions for user display
  - (priv fn) `fn format_structure(s: &TermStructure) -> String` — Format a TermStructure for display
  - (pub fn) `pub fn to_proposal(` — Convert a LoogleResult with applicability check into a Proposal
  - (priv fn) `fn compute_proposal_id(anchor: &str, lemma_id: &str, confidence: f32) -> String` — Compute deterministic proposal ID via SHA256 content addressing Format: sha256("loogle:v1" || anchor || lemma_id || confidence)
  - (pub struct) `pub struct LemmaPayload`

### `src/loogle/code_actions.rs`
- uses:
  - `crate::loogle::{check_applicability, to_proposal, LoogleResult}`
  - `tower_lsp::lsp_types::{CodeAction, CodeActionKind, WorkspaceEdit, TextEdit, Range}`
  - `std::collections::HashMap`
  - `new_surface_syntax::proof_state::ProofState`
- items:
  - (pub fn) `pub fn generate_loogle_actions(` — Loogle code actions for lemma suggestions Generate Loogle-based code actions for the current cursor position
  - (priv fn) `fn create_apply_lemma_action(`

### `src/loogle/context.rs`
- uses:
  - `super::LoogleResult`
  - `super::*`
- items:
  - (pub struct) `pub struct GoalContext` — Goal context module for cursor-position-aware search Provides relevance scoring for lemma suggestions based on the current proof context (goal fingerprint, surrounding bindings). Context information about the current goal being proved
  - (priv impl) `impl GoalContext`
  - (pub fn) `pub fn new(goal_fingerprint: String) -> Self` — Create a new goal context
  - (pub fn) `pub fn with_bindings(mut self, bindings: Vec<String>) -> Self` — Add surrounding bindings
  - (pub fn) `pub fn with_cursor(mut self, line: usize, col: usize) -> Self` — Add cursor position
  - (pub fn) `pub fn relevance_score(&self, lemma: &LoogleResult) -> f32` — Compute relevance score for a lemma in this context Returns a score between 0.0 and 1.0 indicating how relevant the lemma is to the current goal context.
  - (priv fn) `fn count_matching_bindings(&self, lemma: &LoogleResult) -> usize` — Count how many local bindings are mentioned in the lemma
  - (pub fn) `pub fn rank_results(&self, results: Vec<LoogleResult>) -> Vec<(LoogleResult, f32)>` — Filter and sort lemma results by relevance to this context
  - (priv fn) `fn fingerprint_similarity(fp1: &str, fp2: &str) -> f32` — Compute approximate similarity between two fingerprints Uses token overlap as a simple heuristic for structural similarity.
  - (priv fn) `fn test_goal_context_basic()`
  - (priv fn) `fn test_fingerprint_similarity_identical()`
  - (priv fn) `fn test_fingerprint_similarity_different()`

### `src/loogle/indexer.rs`
- uses:
  - `super::LoogleIndex`
  - `new_surface_syntax::core::{CoreBundleV0, CompiledRule}`
  - `tcb_core::ast::MorphismTerm`
  - `tcb_core::ast::constructor_registry::TermArg`
  - `std::collections::hash_map::DefaultHasher`
  - `std::hash::{Hash, Hasher}`
- items:
  - (pub const) `pub const LOOGLE_FP_VERSION: u32 = 1;` — Fingerprint format version - increment when changing fingerprint structure to invalidate stale indexes and prevent version drift.
  - (priv const) `const MAX_FP_DEPTH: usize = 32;` — Maximum recursion depth for fingerprinting to prevent runaway on cyclic structures
  - (priv const) `const MAX_FP_NODES: usize = 256;` — Maximum number of nodes to fingerprint before truncation
  - (priv const) `const TRUNCATION_MARKER: &str = "…";` — Truncation marker for fingerprints that exceeded bounds
  - (pub struct) `pub struct WorkspaceIndexer` — Extracts and indexes lemmas from a workspace bundle
  - (priv impl) `impl WorkspaceIndexer`
  - (pub fn) `pub fn new() -> tantivy::Result<Self>`
  - (pub fn) `pub fn reindex(&self, bundle: &CoreBundleV0) -> tantivy::Result<()>` — Re-index the entire workspace from a new bundle
  - (pub fn) `pub fn index(&self) -> &LoogleIndex` — Get the underlying index for search operations
  - (priv fn) `fn is_lemma(rule: &CompiledRule) -> bool` — Check if a rule is marked as a lemma
  - (priv fn) `fn extract_lemma_name(rule: &CompiledRule) -> String` — Extract a human-readable name from the rule metadata or synthesize one
  - (pub fn) `pub fn compute_fingerprint(term: &tcb_core::ast::MorphismTerm) -> String` — Compute a structural fingerprint for search indexing This produces a canonical, deterministic string representation of the term structure that can be used for structural search. The format captures term shape while abstracting over specific IDs. Format: `v{VERSION}:{fingerprint}` **Invariant G6**: No Debug-derived strings used in fingerprints. All formatting uses stable, versioned accessors.
  - (priv struct) `struct FingerprintContext` — Fingerprinting context for tracking bounds
  - (priv impl) `impl FingerprintContext`
  - (priv fn) `fn new() -> Self`
  - (priv fn) `fn exceeded(&self) -> bool` — Check if we've exceeded bounds
  - (priv fn) `fn enter(&mut self) -> bool` — Enter a child node, returning true if we should process it
  - (priv fn) `fn exit(&mut self)` — Exit a child node
  - (priv fn) `fn truncate(&mut self) -> String` — Mark as truncated and return truncation marker
  - (priv fn) `fn compute_fingerprint_bounded(` — Bounded fingerprinting with depth/node tracking
  - (priv fn) `fn format_term_arg(arg: &tcb_core::ast::constructor_registry::TermArg) -> String` — Format a term argument for fingerprinting
  - (priv fn) `fn compute_hash(term: &tcb_core::ast::MorphismTerm) -> u64` — Compute stable hash for synthesized names
  - (priv fn) `fn extract_doc_string(rule: &CompiledRule) -> String` — Extract documentation string from rule metadata

### `src/loogle/mod.rs`
- modules:
  - `pub mod indexer;`
  - `pub mod applicability;`
  - `pub mod code_actions;`
  - `pub mod context;`
- uses:
  - `tantivy::schema::*`
  - `tantivy::{Index, IndexWriter, IndexReader, ReloadPolicy, doc}`
  - `tantivy::collector::TopDocs`
  - `tantivy::query::QueryParser`
  - `tantivy::TantivyDocument`
  - `std::sync::{Arc, RwLock}`
- items:
  - (pub struct) `pub struct LoogleIndex`
  - (priv impl) `impl LoogleIndex`
  - (pub fn) `pub fn new_in_memory() -> tantivy::Result<Self>`
  - (pub fn) `pub fn index_lemma(` — Index a lemma from the workspace bundle
  - (pub fn) `pub fn search(&self, query_fp: &str, limit: usize) -> tantivy::Result<Vec<LoogleResult>>` — Search for lemmas by structural fingerprint
  - (pub fn) `pub fn clear(&self) -> tantivy::Result<()>` — Clear all indexed lemmas (for re-indexing)
  - (pub struct) `pub struct LoogleResult`

### `src/lsp.rs`
- uses:
  - `std::{sync::Arc, time::Duration}`
  - `serde::{Deserialize, Serialize}`
  - `source_span::Span`
  - `tokio::sync::{mpsc, RwLock}`
  - `tokio::process::Command`
  - `tokio::time::{self, Instant}`
  - `crate::proof_session::{ProofSession, ProofSessionOpenResult, ProofSessionUpdateResult}`
  - `new_surface_syntax::comrade_workspace::WorkspaceReport`
  - `sniper_db::SniperDatabase`
  - `async_trait::async_trait`
  - `crate::tactics::view::ActionKind`
  - `super::*`
  - `crate::document::ParsedDocument`
  - `new_surface_syntax::comrade_workspace::WorkspaceReport`
  - `new_surface_syntax::{WorkspaceDiagnostic, WorkspaceDiagnosticSeverity}`
- items:
  - (priv const) `const EXTERNAL_COMMAND_TIMEOUT_MS: u64 = 5000;`
  - (priv const) `const DEFAULT_DEBOUNCE_INTERVAL_MS: u64 = 250;`
  - (priv const) `const DEFAULT_LOG_LEVEL: &str = "info";`
  - (priv const) `const DEFAULT_EXTERNAL_COMMAND: Option<&str> = None;`
  - (priv fn) `fn is_identifier_char(c: char) -> bool`
  - (priv fn) `fn symbol_at_position(text: &str, position: Position) -> Option<String>`
  - (priv fn) `fn render_hover_markdown(from: &str, to: &str, report: &sniper_db::plan::PlanReport, debug_mode: bool) -> String`
  - (pub struct) `pub struct DebouncedDocumentChange`
  - (pub struct) `pub struct Config`
  - (priv impl) `impl Default for Config`
  - (priv fn) `fn default() -> Self`
  - (priv fn) `fn parse_external_output_to_diagnostics(_uri: &Url, output_line: &str) -> Diagnostic`
  - (priv fn) `async fn run_external_command_and_parse_diagnostics(`
  - (priv fn) `fn workspace_report_to_diagnostics(report: &WorkspaceReport, text: &str) -> Vec<Diagnostic>`
  - (pub fn) `pub fn document_diagnostics_from_report(`
  - (priv fn) `fn diagnostic_sort_key<'a>(`
  - (priv fn) `fn diagnostic_code_to_str(code: Option<&NumberOrString>) -> String`
  - (priv fn) `fn diagnostic_source_to_str(source: Option<&String>) -> &str`
  - (priv fn) `fn sort_diagnostics(uri: &Url, diagnostics: &mut Vec<Diagnostic>)`
  - (priv fn) `fn workspace_severity_to_lsp(severity: WorkspaceDiagnosticSeverity) -> DiagnosticSeverity`
  - (priv fn) `fn severity_rank(severity: Option<DiagnosticSeverity>) -> u8`
  - (priv fn) `fn clamp_span(span: Span, text_len: usize) -> Span`
  - (priv fn) `fn byte_span_to_range(text: &str, span: ByteSpan) -> Range`
  - (priv fn) `fn chain_to_selection_range(text: &str, chain: &[ByteSpan]) -> SelectionRange`
  - (pub fn) `pub fn workspace_error_report(err: &SurfaceError) -> WorkspaceReport`
  - (pub struct) `pub struct Backend`
  - (priv impl) `impl Backend`
  - (pub fn) `pub fn new(client: Client, config: Arc<RwLock<Config>>) -> Self { // Changed client type`
  - (priv fn) `async fn hover_db7_preview(&self, uri: &Url, position: Position) -> Option<Hover>` — DB-7 hover preview: show rename impact analysis
  - (priv fn) `async fn code_action_db7_preview(&self, uri: &Url, position: Position) -> Option<tower_lsp::lsp_types::CodeAction>` — DB-7 code action: offer "Preview Rename Impact" action
  - (priv fn) `async fn code_action_db7_preview_detailed(&self, uri: &Url, position: Position) -> Option<tower_lsp::lsp_types::CodeAction>` — DB-7 code action (detailed): offer "Preview Rename Impact (Detailed)" action
  - (priv fn) `async fn code_action_db7_preview_internal(` — Internal helper for DB-7 code actions
  - (priv fn) `async fn process_debounced_proof_session_events(`
  - (priv impl) `impl LanguageServer for Backend`
  - (priv fn) `async fn initialize(&self, params: InitializeParams) -> Result<InitializeResult>`
  - (priv fn) `async fn initialized(&self, _: InitializedParams)`
  - (priv fn) `async fn shutdown(&self) -> Result<()>`
  - (priv fn) `async fn did_open(&self, params: DidOpenTextDocumentParams)`
  - (priv fn) `async fn did_change(&self, params: DidChangeTextDocumentParams)`
  - (priv fn) `async fn did_save(&self, params: DidSaveTextDocumentParams)`
  - (priv fn) `async fn did_close(&self, params: DidCloseTextDocumentParams)`
  - (priv fn) `async fn hover(&self, params: HoverParams) -> Result<Option<Hover>>`
  - (priv fn) `async fn execute_command(&self, params: ExecuteCommandParams) -> Result<Option<serde_json::Value>>`
  - (priv fn) `async fn code_action(&self, params: CodeActionParams) -> Result<Option<CodeActionResponse>>`
  - (priv fn) `async fn selection_range(`
  - (priv fn) `async fn inlay_hint(&self, params: InlayHintParams) -> Result<Option<Vec<InlayHint>>>`
  - (priv fn) `async fn semantic_tokens_full(`
  - (priv fn) `async fn document_symbol(`
  - (priv fn) `async fn diagnostic(`
  - (priv fn) `fn map_tactic_kind(kind: crate::tactics::view::ActionKind) -> tower_lsp::lsp_types::CodeActionKind`
  - (priv fn) `fn sample_report() -> WorkspaceReport`
  - (priv fn) `fn workspace_report_to_diagnostics_is_deterministic()`
  - (priv fn) `fn document_diagnostics_include_workspace_report_diag()`
  - (priv fn) `fn test_extract_trace_steps_v1()`
  - (priv fn) `async fn test_extract_trace_steps_legacy()`
  - (priv fn) `fn test_extract_trace_steps_no_match()`

### `src/main.rs`
- uses:
  - `edgelord_lsp::{Backend, lsp::Config}`
  - `tower_lsp::{LspService, Server}`
  - `tokio::sync::RwLock`
  - `std::sync::Arc`
- items:
  - (priv fn) `async fn main()`

### `src/proof_session.rs`
- uses:
  - `std::{collections::{BTreeMap, VecDeque}, sync::Arc}`
  - `tokio::sync::RwLock`
  - `tokio::time::Instant`
  - `crate::document::{apply_content_changes, ParsedDocument, Goal}`
  - `crate::lsp::{Config, workspace_error_report, document_diagnostics_from_report}`
  - `new_surface_syntax::comrade_workspace::WorkspaceReport`
  - `new_surface_syntax::ComradeWorkspace`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
  - `new_surface_syntax::diagnostics::DiagnosticContext`
  - `new_surface_syntax::diagnostics::ByteSpan`
  - `super::*`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
  - `new_surface_syntax::proof_state::{ProofState, MetaSubst, ElaborationTrace, GoalState, HoleOwner, MorMetaId, LocalContext, MorType, ObjExpr, GoalStatus}`
  - `new_surface_syntax::diagnostics::{DiagnosticContext, ByteSpan}`
  - `tower_lsp::lsp_types::Url`
- items:
  - (pub struct) `pub struct ProofSnapshot`
  - (pub struct) `pub struct ProofDocument`
  - (pub struct) `pub struct ProofSessionOpenResult`
  - (pub struct) `pub struct ProofSessionUpdateResult`
  - (pub struct) `pub struct ProofSession`
  - (priv impl) `impl ProofSession`
  - (pub fn) `pub fn new(client: Client, config: Arc<RwLock<Config>>) -> Self { // Changed client type`
  - (pub fn) `pub async fn open(&mut self, uri: Url, version: i32, initial_text: String) -> ProofSessionOpenResult`
  - (pub fn) `pub async fn update(&mut self, uri: Url, version: i32, changes: Vec<TextDocumentContentChangeEvent>) -> ProofSessionUpdateResult`
  - (pub fn) `pub fn get_document(&self, uri: &Url) -> Option<&ProofDocument>`
  - (pub fn) `pub fn get_goals(&self, uri: &Url) -> Vec<Goal>`
  - (pub fn) `pub fn loogle_index(&self) -> &crate::loogle::WorkspaceIndexer`
  - (pub fn) `pub async fn apply_command(&mut self, uri: Url, _command: String) -> ProofSessionUpdateResult`
  - (pub fn) `pub fn get_document_text(&self, uri: &Url) -> Option<String>`
  - (pub fn) `pub fn get_document_version(&self, uri: &Url) -> Option<i32>`
  - (pub fn) `pub fn get_last_analyzed_time(&self, uri: &Url) -> Option<Instant>`
  - (pub fn) `pub fn get_parsed_document(&self, uri: &Url) -> Option<&ParsedDocument>`
  - (pub fn) `pub fn get_proof_state(&self, uri: &Url) -> Option<&new_surface_syntax::proof_state::ProofState>`
  - (pub fn) `pub fn get_diagnostics(&self, uri: &Url) -> Vec<Diagnostic>`
  - (pub fn) `pub fn resolve_goal_anchor(&self, uri: &Url, anchor_id: &str) -> Option<(new_surface_syntax::proof_state::MorMetaId, Option<new_surface_syntax::diagnostics::ByteSpan>)>`
  - (pub fn) `pub fn close(&mut self, uri: &Url)`
  - (pub fn) `pub fn compute_goals_panel(&self, uri: &Url) -> Option<crate::goals_panel::GoalsPanelResponse>`
  - (priv fn) `fn compute_ui_goals(`
  - (priv fn) `fn test_compute_ui_goals_stability()`
  - (priv fn) `fn compute_structural_summary(goal: &new_surface_syntax::proof_state::GoalState) -> String`

### `src/proposal.rs`
- uses:
  - `serde::{Serialize, Deserialize}`
- items:
  - (pub struct) `pub struct Proposal<T>` — A universal protocol for knowledge-sharing suggestions.
  - (pub enum) `pub enum ProposalKind`
  - (pub enum) `pub enum ProposalStatus`
  - (pub struct) `pub struct EvidenceSummary`
  - (pub struct) `pub struct ReconstructionPlan`

### `src/refute/lsp_handler.rs`

LSP handler for edgelord/refute endpoint.

This module provides the stable JSON contract for refutation.

- uses:
  - `serde::{Deserialize, Serialize}`
  - `sha2::{Sha256, Digest}`
  - `crate::proposal::{Proposal, ProposalKind, ProposalStatus, EvidenceSummary}`
  - `crate::refute::types::{BoundedList, RefuteLimits, StableAnchor, AnchorKind, DecisionInfo}`
  - `crate::refute::witness::{CounterexamplePayload, Counterexample, FailureWitness, InterpretationSummary, InterpretationKind, DiagramBoundary}`
  - `crate::refute::probe::ProbeKey`
  - `crate::refute::slice::SliceSummary`
  - `std::time::{SystemTime, UNIX_EPOCH}`
  - `super::*`
- items:
  - (pub const) `pub const REFUTE_PROTOCOL_VERSION: u32 = 1;` — Version of the refute protocol. Bump on breaking changes.
  - (pub struct) `pub struct RefuteRequest` — Request for refutation.
  - (pub struct) `pub struct RefuteResponse` — Response envelope for refutation. **Invariant**: Field names and ordering are stable. Bump `version` on breaking changes.
  - (pub struct) `pub struct RefuteMeta` — Metadata about the refutation request.
  - (pub fn) `pub fn sort_proposals(proposals: &mut [Proposal<CounterexamplePayload>])` — Sort proposals deterministically. Order by: status, level, probe, score (desc), failure fingerprint, id
  - (priv fn) `fn status_rank(status: &ProposalStatus) -> u8`
  - (priv fn) `fn failure_fingerprint(witness: &FailureWitness) -> String` — Compute fingerprint for a failure witness.
  - (pub fn) `pub fn generate_proposal_id(anchor: &str, probe: &ProbeKey, witness: &FailureWitness) -> String` — Generate deterministic proposal ID from (anchor, probe, witness fingerprint).
  - (pub fn) `pub fn handle_refute_request(` — Handle a refute request and return a stable response. **Invariant**: Output is byte-for-byte deterministic for same input.
  - (priv fn) `fn create_missing_coherence_proposal(` — Create a MissingCoherenceWitness proposal for level ≥ 1.
  - (priv fn) `fn current_timestamp_ms() -> u64`
  - (priv fn) `fn round_score(score: f32) -> f32`
  - (priv fn) `fn test_generate_proposal_id_deterministic()`
  - (priv fn) `fn test_handle_refute_deterministic()`
  - (priv fn) `fn test_coherence_level_1_returns_missing_witness()`

### `src/refute/mod.rs`

Mac Lane-native refutation engine.

This module provides doctrine-agnostic refutation via probe doctrines.
Probes enumerate interpretations and check whether obligations hold.

# Architecture

- `types`: Core bounded types (BoundedList, RefuteLimits)
- `slice`: Theory slice extraction from ProofState
- `probe`: ProbeDoctrine trait and check results
- `witness`: Counterexample and FailureWitness types
- `orchestrator`: Refuter that tries probes in order
- `probes/`: MVP probe implementations
- `render`: Witness rendering via PrettyCtx

- modules:
  - `pub mod types;`
  - `pub mod slice;`
  - `pub mod probe;`
  - `pub mod witness;`
  - `pub mod orchestrator;`
  - `pub mod probes;`
  - `pub mod render;`
  - `pub mod lsp_handler;`

### `src/refute/orchestrator.rs`

Refuter orchestrator.

Tries probes in deterministic priority order and returns the
first valid counterexample as a Proposal.

- uses:
  - `std::sync::Arc`
  - `crate::proposal::{Proposal, ProposalKind, ProposalStatus, EvidenceSummary}`
  - `crate::refute::types::{RefuteLimits, StableAnchor, DecisionInfo}`
  - `crate::refute::probe::{ProbeDoctrine, ProbeKey, RefuteCheckResult, InterpretationData}`
  - `crate::refute::slice::{RefuteSlice, SliceSummary}`
  - `crate::refute::witness::{CounterexamplePayload, Counterexample, InterpretationSummary, InterpretationKind, FailureWitness}`
  - `serde::{Deserialize, Serialize}`
  - `sha2::{Sha256, Digest}`
  - `crate::refute::probes::rewrite_probe::RewriteProbe`
- items:
  - (pub struct) `pub struct RefuteRequest` — Request for refutation.
  - (pub struct) `pub struct Refuter` — Main refuter orchestrator. **Invariants**: - Deterministic probe ordering - Returns Proposal<CounterexamplePayload>, not bespoke result - ProposalStatus::Advisory always for Phase 10
  - (priv impl) `impl Refuter`
  - (pub fn) `pub fn new(probes: Vec<Arc<dyn ProbeDoctrine>>) -> Self` — Create a new refuter with the given probes.
  - (pub fn) `pub fn with_default_probes() -> Self` — Create a refuter with default MVP probes.
  - (pub fn) `pub fn refute(` — Run refutation and return a Proposal. **Semantics**: - Tries probes in deterministic order - Returns first counterexample found - Returns "no counterexample within bounds" if nothing found
  - (priv fn) `fn probes_in_order<'a>(` — Get probes in deterministic order for this slice.
  - (priv fn) `fn make_proposal(` — Create a proposal from a counterexample.
  - (priv fn) `fn make_no_counterexample_proposal(` — Create a "no counterexample found" proposal.
  - (priv fn) `fn compute_proposal_id(` — Compute deterministic proposal ID.

### `src/refute/probe.rs`

Probe trait and core probe types.

A probe doctrine is a small semantic world we can map into and evaluate.
This is the Mac Lane-native approach: interpretations are first-class objects.

- uses:
  - `serde::{Deserialize, Serialize}`
  - `crate::refute::types::{BoundedList, RefuteLimits, RefuteFragment, TruncationReason}`
  - `crate::refute::slice::RefuteSlice`
  - `crate::refute::witness::FailureWitness`
- items:
  - (pub struct) `pub struct ProbeKey` — Stable identity for a probe doctrine. **Mac Lane move**: includes deformation level and semantic description for education + ML training data.
  - (pub struct) `pub struct InterpretationCandidate` — A candidate interpretation from a probe doctrine. Stored structurally; rendered via PrettyCtx at the boundary.
  - (pub enum) `pub enum InterpretationData` — Probe-specific interpretation data.
  - (pub enum) `pub enum RefuteCheckResult` — Result of checking an interpretation. **Critical invariant**: `NoFailureFoundWithinBounds` is NOT a counterexample. Only `FoundFailure` with a witness counts as refutation.
  - (pub trait) `pub trait ProbeDoctrine: Send + Sync` — A probe doctrine for Mac Lane-native refutation. Probes enumerate interpretations and check whether obligations hold. This is doctrine-agnostic: the same interface works for rewrite probes, finite category probes, and (eventually) SMT probes.
  - (priv fn) `fn key(&self) -> ProbeKey;` — Stable identity for this probe.
  - (priv fn) `fn max_level(&self) -> u8;` — Maximum coherence level this probe supports.
  - (priv fn) `fn supports_fragment(&self, frag: &RefuteFragment) -> bool;` — Whether this probe can handle the given fragment.
  - (priv fn) `fn enumerate_interpretations(` — Enumerate candidate interpretations (bounded, deterministic).
  - (priv fn) `fn check(` — Check whether obligations hold under this interpretation. **Invariant**: Must return `NoFailureFoundWithinBounds` on timeout, not `FoundFailure`. Only genuine obstructions yield `FoundFailure`.

### `src/refute/probes/finite_cat_probe.rs`

Finite skeletal category probe (MVP Probe B).

Checks obligations in small finite categories (N≤3 default).
Returns UnsupportedFragment if categorical presentation not extractable.

- uses:
  - `crate::refute::types::{BoundedList, RefuteLimits, RefuteFragment, TruncationReason}`
  - `crate::refute::slice::RefuteSlice`
  - `super::*`
  - `crate::refute::types::{StableAnchor, AnchorKind}`
- items:
  - (pub struct) `pub struct FiniteCatProbe;` — Finite skeletal category probe. **Semantics**: - Domain: objects 0..N-1 - Morphisms: generated by slice with explicit composition - Checks: composition, identities, associativity - Returns `UnsupportedFragment` if categorical presentation not extractable
  - (priv impl) `impl FiniteCatProbe`
  - (pub fn) `pub fn new() -> Self`
  - (priv impl) `impl ProbeDoctrine for FiniteCatProbe`
  - (priv fn) `fn key(&self) -> ProbeKey`
  - (priv fn) `fn max_level(&self) -> u8`
  - (priv fn) `fn supports_fragment(&self, frag: &RefuteFragment) -> bool`
  - (priv fn) `fn enumerate_interpretations(`
  - (priv fn) `fn check(`
  - (priv impl) `impl Default for FiniteCatProbe`
  - (priv fn) `fn default() -> Self`
  - (priv fn) `fn test_finite_cat_probe_key()`
  - (priv fn) `fn test_finite_cat_probe_supports_categorical()`
  - (priv fn) `fn test_enumerate_respects_limits()`

### `src/refute/probes/mod.rs`

Probe implementations submodule.

- modules:
  - `pub mod rewrite_probe;`
  - `pub mod finite_cat_probe;`

### `src/refute/probes/rewrite_probe.rs`

Rewrite obstruction probe (MVP Probe A).

Detects failures via rewriting: non-joinable peaks, critical pairs.
Returns honest results: only FoundFailure when genuine obstruction found.

- uses:
  - `crate::refute::types::{BoundedList, RefuteLimits, RefuteFragment, TruncationReason}`
  - `crate::refute::slice::{RefuteSlice, Obligation}`
  - `crate::refute::witness::FailureWitness`
  - `super::*`
  - `crate::refute::slice::TermRef`
  - `crate::refute::types::{StableAnchor, AnchorKind}`
- items:
  - (pub struct) `pub struct RewriteProbe;` — Rewrite obstruction probe. **Semantics**: - Treats slice as a rewriting system - Searches for non-joinable peaks / critical pairs - Returns `NoFailureFoundWithinBounds` on timeout (NOT a false refutation)
  - (priv impl) `impl RewriteProbe`
  - (pub fn) `pub fn new() -> Self`
  - (priv impl) `impl ProbeDoctrine for RewriteProbe`
  - (priv fn) `fn key(&self) -> ProbeKey`
  - (priv fn) `fn max_level(&self) -> u8`
  - (priv fn) `fn supports_fragment(&self, frag: &RefuteFragment) -> bool`
  - (priv fn) `fn enumerate_interpretations(`
  - (priv fn) `fn check(`
  - (priv impl) `impl Default for RewriteProbe`
  - (priv fn) `fn default() -> Self`
  - (priv fn) `fn test_slice_with_obligations(obligations: Vec<Obligation>) -> RefuteSlice`
  - (priv fn) `fn test_rewrite_probe_key()`
  - (priv fn) `fn test_rewrite_probe_supports_equational()`
  - (priv fn) `fn test_rewrite_probe_finds_nonjoinable_peak()`
  - (priv fn) `fn test_rewrite_probe_no_failure_for_equal()`

### `src/refute/render.rs`

Witness rendering (MVVM separation).

Keeps witnesses structural; renders to pretty text at the boundary.

- uses:
  - `crate::refute::witness::{Counterexample, FailureWitness}`
  - `super::*`
  - `crate::refute::probe::ProbeKey`
  - `crate::refute::slice::SliceSummary`
  - `crate::refute::types::{BoundedList, JumpTarget}`
- items:
  - (pub fn) `pub fn render_counterexample(cx: &Counterexample) -> String` — Render a counterexample to human-readable text.
  - (pub fn) `pub fn render_failure_witness(witness: &FailureWitness) -> String` — Render a failure witness to human-readable text.
  - (pub struct) `pub struct RefuteExplanationNode` — A simplified ExplanationNode for refutation witnesses. This mirrors the structure in `explain::view` but is standalone for the refute module to avoid circular dependencies.
  - (priv impl) `impl RefuteExplanationNode`
  - (pub fn) `pub fn leaf(label: String, kind: &str) -> Self`
  - (pub fn) `pub fn with_jump(mut self, start: usize, end: usize) -> Self`
  - (pub fn) `pub fn witness_to_explanation_tree(witness: &FailureWitness) -> RefuteExplanationNode` — Convert a failure witness to an explanation tree. **Invariant**: All labels PrettyCtx-rendered, jump targets byte-offset. UTF-16 conversion happens at LSP boundary via `byte_to_utf16_offset`.
  - (pub fn) `pub fn validate_tree_spans(node: &RefuteExplanationNode, text_len: usize) -> bool` — Validate that all jump targets in a tree are within bounds. Returns `true` if all spans are valid.
  - (priv fn) `fn test_render_equation_failure()`
  - (priv fn) `fn test_witness_to_explanation_tree()`
  - (priv fn) `fn test_utf16_jump_target_validity()`

### `src/refute/slice.rs`

Refutation slice extraction.

A RefuteSlice is a minimal, trace-driven theory slice containing:
- Target obligation(s)
- Minimal blocker set
- Bounded neighborhood of rules/defs from trace graph

- uses:
  - `serde::{Deserialize, Serialize}`
  - `crate::refute::types::{BoundedList, RefuteLimits, TruncationReason, StableAnchor, AnchorKind}`
  - `super::*`
- items:
  - (pub struct) `pub struct RefuteSlice` — A minimal theory slice for refutation. **Key invariants**: - `anchor` is structured (not String) - Obligations sorted deterministically - Rules/defs bounded by trace neighborhood
  - (pub struct) `pub struct Obligation` — An obligation to check in the refutation.
  - (pub struct) `pub struct TermRef` — Reference to a term (structural, rendered via PrettyCtx).
  - (pub struct) `pub struct RuleRef` — Reference to a rule in the slice.
  - (pub struct) `pub struct DefRef` — Reference to a definition in the slice.
  - (pub struct) `pub struct CoherenceObligation` — A coherence obligation for level≥1 proofs. When coherence level > 0, the slice includes diagram boundaries that need to be checked or surfaced as "missing coherence" if undecidable.
  - (pub struct) `pub struct DiagramBoundary` — A diagram boundary requiring a higher cell.
  - (pub struct) `pub struct SliceSummary` — Summary of what was included in the slice. Explicitly educational: shows what was assumed for the refutation.
  - (priv impl) `impl SliceSummary`
  - (pub fn) `pub fn from_slice(slice: &RefuteSlice, trace_steps: usize) -> Self` — Create summary from a slice.
  - (pub fn) `pub fn extract_slice(` — Extract a minimal slice for refutation. **Policy**: - Start from target goal/constraint - Include minimal blockers (from GoalsIndex) - Include rules/defs from trace neighborhood up to max_trace_steps - Deterministic sort everywhere
  - (priv fn) `fn test_anchor() -> StableAnchor`
  - (priv fn) `fn test_extract_slice_empty()`

### `src/refute/types.rs`

Core types for Mac Lane-native refutation engine.

These types follow the universal bounded list schema and use structured
internal representations (no pre-rendered strings).

- uses:
  - `serde::{Deserialize, Serialize}`
  - `super::*`
- items:
  - (pub struct) `pub struct StableAnchor` — A stable identifier for a proof artifact. This is a local copy to avoid deep dependency paths. Matches the structure in `new_surface_syntax::diagnostics::anchors`.
  - (pub enum) `pub enum AnchorKind`
  - (priv impl) `impl StableAnchor`
  - (pub fn) `pub fn to_id_string(&self) -> String` — Compute the deterministic string ID.
  - (pub fn) `pub fn test(kind: AnchorKind, file: &str, ordinal: u32) -> Self` — Create a test anchor.
  - (pub struct) `pub struct BoundedList<T>` — A bounded list with full truncation tracking. **Invariant**: This is the universal bounded list type used across EdgeLorD (refute, explain, loogle). Always includes: - `total_count`: how many items existed before capping - `truncation_reason`: why we stopped (if truncated)
  - (pub fn) `pub fn from_vec(items: Vec<T>) -> Self` — Create a non-truncated list.
  - (pub fn) `pub fn truncated(items: Vec<T>, total_count: usize, reason: TruncationReason) -> Self` — Create a truncated list.
  - (pub fn) `pub fn empty() -> Self` — Create an empty list.
  - (priv fn) `fn default() -> Self`
  - (pub enum) `pub enum TruncationReason` — Reason for truncation in bounded operations.
  - (pub struct) `pub struct DecisionInfo` — Uniform decision envelope for every witness. This prevents clients from having to interpret enum variants as policy.
  - (priv impl) `impl DecisionInfo`
  - (pub fn) `pub fn decided() -> Self` — Decided failure within decidable fragment.
  - (pub fn) `pub fn not_found(reason: &str) -> Self` — Decidable but no failure found.
  - (pub fn) `pub fn undecidable(reason: &str) -> Self` — Not decidable by this probe.
  - (pub struct) `pub struct JumpTarget` — A structured jump target for explain/UI integration.
  - (priv impl) `impl JumpTarget`
  - (pub fn) `pub fn from_span(start: usize, end: usize) -> Self`
  - (pub fn) `pub fn with_label(mut self, label: &str) -> Self`
  - (pub fn) `pub fn with_kind(mut self, kind: &str) -> Self`
  - (pub struct) `pub struct ByteSpan` — Byte span for jump targets.
  - (pub struct) `pub struct RefuteLimits` — Resource limits for refutation. Defaults are conservative for fast p95 response times.
  - (priv impl) `impl Default for RefuteLimits`
  - (priv fn) `fn default() -> Self`
  - (pub enum) `pub enum RefuteFragment` — Fragment of theory that a probe can handle. Used for "honest unsupported" - probes decline fragments they can't check.
  - (priv impl) `impl RefuteFragment`
  - (pub fn) `pub fn level(&self) -> u8` — The coherence level this fragment requires.
  - (priv fn) `fn test_bounded_list_from_vec()`
  - (priv fn) `fn test_bounded_list_truncated()`
  - (priv fn) `fn test_refute_limits_default()`

### `src/refute/witness.rs`

Witness types for refutation failures.

Witnesses are pedagogical artifacts, not solver dumps.
They're stored structurally and rendered via PrettyCtx.

- uses:
  - `serde::{Deserialize, Serialize}`
  - `crate::refute::types::{BoundedList, DecisionInfo, JumpTarget}`
  - `crate::refute::probe::ProbeKey`
  - `crate::refute::slice::SliceSummary`
- items:
  - (pub struct) `pub struct Counterexample` — A counterexample found by refutation. This is the payload for `Proposal<CounterexamplePayload>`.
  - (pub struct) `pub struct InterpretationSummary` — Summary of an interpretation for display.
  - (pub enum) `pub enum InterpretationKind` — Tagged interpretation kind for forward compatibility.
  - (pub enum) `pub enum FailureWitness` — A witness to a failure in the interpretation. **Mac Lane-native**: This is not a "model" - it's a failed obligation described in the language of proof objects (explainable + teachable).
  - (pub struct) `pub struct DiagramBoundary` — A diagram boundary requiring a higher cell. Machine-facing structure for UI, explain integration, and diagram workflows.
  - (pub struct) `pub struct CounterexamplePayload` — Payload for `Proposal<CounterexamplePayload>`. Wraps Counterexample with additional context for the proposal protocol.
  - (priv impl) `impl CounterexamplePayload`
  - (pub fn) `pub fn new(counterexample: Counterexample) -> Self`

### `src/span_conversion.rs`
- uses:
  - `source_span::Span`
  - `tower_lsp::lsp_types::{Position, Range}`
  - `super::*`
- items:
  - (pub fn) `pub fn offset_to_position(text: &str, offset: usize) -> Option<Position>` — Converts a byte offset to an LSP Position (line, character), using UTF-16 code units. This function is the canonical way to convert from internal byte offsets to LSP positions. It handles UTF-16 surrogate pairs correctly, which is required by the LSP spec.
  - (pub fn) `pub fn position_to_offset(text: &str, position: Position) -> Option<usize>` — Converts an LSP Position (line, character) to a byte offset. This is the inverse of `offset_to_position`. It interprets the character index as a count of UTF-16 code units.
  - (pub fn) `pub fn byte_span_to_lsp_range(text: &str, span: Span) -> Option<Range>` — Converts an internal byte Span to an LSP Range. Uses `offset_to_position` for start and end, ensuring consistent UTF-16 handling.
  - (priv fn) `fn ascii_only()`
  - (priv fn) `fn multibyte_unicode_emoji()`
  - (priv fn) `fn multibyte_cjk()`
  - (priv fn) `fn crlf_line_endings()`
  - (priv fn) `fn empty_spans()`
  - (priv fn) `fn eof_positions()`
  - (priv fn) `fn out_of_bounds()`
  - (priv fn) `fn middle_of_multibyte_error()`

### `src/tactics/edit.rs`
- uses:
  - `tower_lsp::lsp_types::{WorkspaceEdit, TextEdit, Url, Range}`
  - `std::collections::HashMap`
  - `crate::document::ByteSpan`
- items:
  - (pub struct) `pub struct EditBuilder` — Helper to build WorkspaceEdits for tactics.
  - (priv impl) `impl EditBuilder`
  - (pub fn) `pub fn new(uri: Url, text: String) -> Self`
  - (pub fn) `pub fn replace_span(&self, span: ByteSpan, new_text: String) -> WorkspaceEdit` — Create a WorkspaceEdit that replaces the given span with new text.
  - (pub fn) `pub fn insert_before_span(&self, span: ByteSpan, new_text: String) -> WorkspaceEdit` — Create a WorkspaceEdit that inserts text before the given span.
  - (pub fn) `pub fn wrap_span(&self, span: ByteSpan, prefix: String, suffix: String) -> WorkspaceEdit` — Wrap a span with a prefix and suffix.
  - (priv fn) `fn span_to_range(&self, span: ByteSpan) -> Range`
  - (priv fn) `fn offset_to_position(&self, offset: usize) -> tower_lsp::lsp_types::Position`

### `src/tactics/mod.rs`
- modules:
  - `pub mod view;`
  - `pub mod registry;`
  - `pub mod query;`
  - `pub mod edit;`
  - `pub mod stdlib;`

### `src/tactics/query.rs`
- uses:
  - `crate::tactics::view::Selection`
  - `crate::document::ParsedDocument`
  - `crate::document::ByteSpan`
  - `new_surface_syntax::proof_state::{ProofState, MorMetaId, GoalStatus}`
  - `std::collections::BTreeSet`
- items:
  - (pub trait) `pub trait TacticQuery` — High-level query interface for tactics.
  - (priv fn) `fn node_at_cursor(&self, doc: &ParsedDocument, selection: &Selection) -> Option<ByteSpan>;` — Find the innermost AST node at the selection.
  - (priv fn) `fn goal_at_cursor(&self, doc: &ParsedDocument, selection: &Selection) -> Option<MorMetaId>;` — Find the goal ID at the selection.
  - (priv fn) `fn blockers_for_goal(&self, proof: &ProofState, goal_id: MorMetaId) -> BTreeSet<MorMetaId>;` — Get the set of metas that directly block the given goal.
  - (priv fn) `fn macro_call_at_cursor(&self, doc: &ParsedDocument, selection: &Selection) -> Option<String>;` — Find if the selection is inside a macro call and return the macro name.
  - (pub struct) `pub struct SemanticQuery;`
  - (priv impl) `impl SemanticQuery`
  - (pub fn) `pub fn new() -> Self`
  - (priv impl) `impl TacticQuery for SemanticQuery`
  - (priv fn) `fn node_at_cursor(&self, doc: &ParsedDocument, selection: &Selection) -> Option<ByteSpan>`
  - (priv fn) `fn goal_at_cursor(&self, doc: &ParsedDocument, selection: &Selection) -> Option<MorMetaId>`
  - (priv fn) `fn blockers_for_goal(&self, proof: &ProofState, goal_id: MorMetaId) -> BTreeSet<MorMetaId>`
  - (priv fn) `fn macro_call_at_cursor(&self, doc: &ParsedDocument, selection: &Selection) -> Option<String>`
  - (priv impl) `impl Default for SemanticQuery`
  - (priv fn) `fn default() -> Self`

### `src/tactics/registry.rs`
- uses:
  - `std::collections::BTreeMap`
  - `std::sync::Arc`
  - `crate::tactics::view::{Tactic, TacticRequest, TacticResult, TacticAction}`
- items:
  - (pub struct) `pub struct TacticRegistry` — A registry for all available tactics. Uses BTreeMap to ensure deterministic iteration order.
  - (priv impl) `impl TacticRegistry`
  - (pub fn) `pub fn new() -> Self`
  - (pub fn) `pub fn register(&mut self, tactic: Arc<dyn Tactic>)` — Register a new tactic.
  - (pub fn) `pub fn compute_all(&self, req: &TacticRequest) -> Vec<TacticAction>` — Compute all applicable actions from all registered tactics.
  - (priv impl) `impl Default for TacticRegistry`
  - (priv fn) `fn default() -> Self`

### `src/tactics/stdlib/goaldirected.rs`
- uses:
  - `crate::tactics::view::{Tactic, TacticRequest, TacticResult, TacticAction, ActionKind, ActionSafety}`
  - `crate::tactics::edit::EditBuilder`
  - `new_surface_syntax::diagnostics::anchors::{StableAnchor, AnchorKind}`
  - `std::collections::BTreeMap`
- items:
  - (pub struct) `pub struct FocusGoalTactic;`
  - (priv impl) `impl Tactic for FocusGoalTactic`
  - (priv fn) `fn id(&self) -> &'static str`
  - (priv fn) `fn title(&self) -> &'static str`
  - (priv fn) `fn compute(&self, req: &TacticRequest) -> TacticResult`

### `src/tactics/stdlib/mod.rs`
- modules:
  - `pub mod quickfix;`
  - `pub mod goaldirected;`
  - `pub mod rewrite;`
- uses:
  - `std::sync::Arc`
  - `crate::tactics::registry::TacticRegistry`
- items:
  - (pub fn) `pub fn register_std_tactics(registry: &mut TacticRegistry)`

### `src/tactics/stdlib/quickfix.rs`
- uses:
  - `crate::tactics::view::{Tactic, TacticRequest, TacticResult, TacticAction, ActionKind, ActionSafety}`
  - `crate::tactics::edit::EditBuilder`
  - `new_surface_syntax::diagnostics::anchors::{StableAnchor, AnchorKind}`
  - `std::collections::BTreeMap`
- items:
  - (pub struct) `pub struct AddTouchTactic;`
  - (priv impl) `impl Tactic for AddTouchTactic`
  - (priv fn) `fn id(&self) -> &'static str`
  - (priv fn) `fn title(&self) -> &'static str`
  - (priv fn) `fn compute(&self, req: &TacticRequest) -> TacticResult`

### `src/tactics/stdlib/rewrite.rs`

### `src/tactics/view.rs`
- uses:
  - `serde::{Deserialize, Serialize}`
  - `std::collections::BTreeMap`
  - `tower_lsp::lsp_types::{Range, WorkspaceEdit}`
  - `new_surface_syntax::proof_state::ProofState`
  - `crate::document::ParsedDocument`
  - `crate::edgelord_pretty_ctx::EdgeLordPrettyCtx`
  - `new_surface_syntax::diagnostics::anchors::StableAnchor`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
- items:
  - (pub struct) `pub struct Selection` — Selection details from the editor.
  - (pub struct) `pub struct TacticLimits` — Resource limits for tactic computation.
  - (priv impl) `impl Default for TacticLimits`
  - (priv fn) `fn default() -> Self`
  - (pub struct) `pub struct TacticRequest<'a>` — Input bundle for a tactic.
  - (pub enum) `pub enum TacticResult` — The result of a tactic proposal.
  - (pub enum) `pub enum ActionSafety` — Safety level of a tactic action.
  - (pub enum) `pub enum ActionKind` — Kind of tactic action for UI grouping.
  - (pub struct) `pub struct TacticAction` — A specific proposal from a tactic.
  - (pub trait) `pub trait Tactic: Send + Sync` — Interface for all tactics.
  - (priv fn) `fn id(&self) -> &'static str;` — Stable identifier for registry (e.g., "std.add_touch").
  - (priv fn) `fn title(&self) -> &'static str;` — Human-readable title of the tactic family.
  - (priv fn) `fn compute(&self, req: &TacticRequest) -> TacticResult;` — Compute proposals for a given request.

### `tests/db7_hover_preview.rs`
- uses:
  - `std::sync::Arc`
  - `tokio::io::{AsyncWriteExt, AsyncBufReadExt, BufStream, duplex, AsyncReadExt}`
  - `tokio::time::{timeout, Duration, Instant}`
  - `serde_json::{json, Value}`
  - `tokio::sync::RwLock`
  - `edgelord_lsp::lsp::{Backend, Config}`
- items:
  - (priv fn) `async fn send_message(stream: &mut BufStream<tokio::io::DuplexStream>, message: Value)`
  - (priv fn) `async fn read_one_message_timeout(`
  - (priv fn) `async fn read_until_response(`
  - (priv fn) `async fn setup_server() -> (`
  - (priv fn) `async fn initialize_server(`
  - (priv fn) `async fn open_document(`
  - (priv fn) `async fn send_hover_request(`
  - (priv fn) `async fn test_smoke_server_lifecycle()`
  - (priv fn) `async fn test_db7_hover_rename_preview_appears()`
  - (priv fn) `async fn test_db7_hover_whitespace_fail_closed()`
  - (priv fn) `async fn test_db7_hover_punctuation_fail_closed()`
  - (priv fn) `async fn test_db7_hover_cache_stability()`
  - (priv fn) `async fn test_db7_hover_file_sync_sanity()`
  - (priv fn) `async fn test_db7_code_action_rename_preview()`

### `tests/diff_tests.rs`
- uses:
  - `edgelord_lsp::diff::engine::compute_diff`
  - `edgelord_lsp::goals_panel::GoalChangeKind`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
  - `new_surface_syntax::diagnostics::DiagnosticContext`
  - `source_span::Span`
- items:
  - (priv fn) `fn test_status_change_diff()`
  - (priv fn) `fn test_blockers_change_diff()`

### `tests/explain_tests.rs`
- uses:
  - `edgelord_lsp::explain::builder::ExplainBuilder`
  - `edgelord_lsp::explain::view::{ExplanationKind, ExplainLimits, validate_span}`
  - `edgelord_lsp::explain::alg_goal::explain_goal`
  - `edgelord_lsp::explain::alg_blocked::explain_why_blocked`
  - `edgelord_lsp::explain::alg_inconsistent::explain_why_inconsistent`
  - `new_surface_syntax::diagnostics::projection::GoalsPanelIndex`
  - `new_surface_syntax::diagnostics::DiagnosticContext`
  - `source_span::Span`
- items:
  - (priv fn) `fn test_builder_determinism()`
  - (priv fn) `fn test_jump_target_validity()`
  - (priv fn) `fn test_explain_why_blocked_snapshot()`
  - (priv fn) `fn test_explain_goal_snapshot()`
  - (priv fn) `fn test_explain_why_inconsistent_snapshot()`

### `tests/highlight_test.rs`
- uses:
  - `edgelord_lsp::highlight::{compute_layer0_structural, tokens_to_lsp_data, SymbolRole}`
- items:
  - (priv fn) `fn test_layer1_highlighting_valid()`
  - (priv fn) `fn test_layer0_fallback_invalid()`

### `tests/integration_tests.rs`
- uses:
  - `std::{sync::Arc}`
  - `tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader, BufStream, duplex, AsyncReadExt}`
  - `tokio::time::{timeout, Duration, Instant}`
  - `serde_json::{json, Value}`
  - `tokio::sync::RwLock`
  - `edgelord_lsp::{lsp::{Backend, Config}}`
- items:
  - (priv fn) `async fn send_message(stream: &mut BufStream<tokio::io::DuplexStream>, message: Value)`
  - (priv fn) `async fn read_one_message(stream: &mut BufStream<tokio::io::DuplexStream>) -> Option<Value>`
  - (priv fn) `async fn test_initialize_did_open_publishes_diagnostics()`
  - (priv fn) `async fn test_debounce_and_single_flight()`

### `tests/loogle_tests.rs`
- uses:
  - `edgelord_lsp::loogle::{LoogleIndex, WorkspaceIndexer, check_applicability}`
  - `edgelord_lsp::loogle::LoogleResult`
  - `edgelord_lsp::loogle::{LoogleResult, ApplicabilityResult, to_proposal}`
  - `edgelord_lsp::loogle::{LoogleResult, ApplicabilityResult, to_proposal}`
  - `edgelord_lsp::loogle::{compute_fingerprint, LOOGLE_FP_VERSION}`
  - `tcb_core::ast::MorphismTerm`
  - `tcb_core::id_minting::GeneratorId`
  - `edgelord_lsp::loogle::{compute_fingerprint, LOOGLE_FP_VERSION}`
  - `tcb_core::ast::MorphismTerm`
  - `edgelord_lsp::loogle::compute_fingerprint`
  - `tcb_core::ast::MorphismTerm`
  - `tcb_core::doctrine::DoctrineKey`
  - `tcb_core::id_minting::GeneratorId`
- items:
  - (priv fn) `fn test_loogle_index_and_search()`
  - (priv fn) `fn test_applicability_check()`
  - (priv fn) `fn test_proposal_generation()`
  - (priv fn) `fn test_proposal_id_determinism()`
  - (priv fn) `fn test_fingerprint_determinism()`
  - (priv fn) `fn test_fingerprint_version_tag()`
  - (priv fn) `fn test_fingerprint_no_debug_format()`

### `tests/mvp0_utilities.rs`
- uses:
  - `tower_lsp::lsp_types::{Position, Range, TextDocumentContentChangeEvent}`
- items:
  - (priv fn) `fn utf16_position_offset_roundtrip_is_stable()`
  - (priv fn) `fn incremental_changes_apply_deterministically()`
  - (priv fn) `fn incremental_changes_respect_input_order()`
  - (priv fn) `fn top_level_symbols_order_is_stable()`
  - (priv fn) `fn selection_chain_validation_rejects_non_nested_spans()`

### `tests/mvp1_2_binders.rs`
- uses:
  - `edgelord_lsp::document::{BindingKind, ParsedDocument}`
- items:
  - (priv fn) `fn let_binder_is_visible_inside_body()`
  - (priv fn) `fn nested_lets_shadow_outer_binders()`
  - (priv fn) `fn local_let_bindings_precede_top_level_bindings()`
  - (priv fn) `fn let_list_binders_are_left_to_right()`

### `tests/mvp1_goals.rs`
- uses:
  - `edgelord_lsp::document::ParsedDocument`
- items:
  - (priv fn) `fn finds_unsolved_goals_with_stable_ids()`
  - (priv fn) `fn goal_context_includes_prior_top_level_bindings()`
  - (priv fn) `fn goal_lookup_by_offset_works()`

### `tests/mvp1_inlay.rs`
- uses:
  - `edgelord_lsp::document::{ByteSpan, ParsedDocument}`
- items:
  - (priv fn) `fn inlay_hints_are_deterministic()`
  - (priv fn) `fn inlay_hints_respect_requested_range()`
  - (priv fn) `fn inlay_hints_order_is_stable_with_same_offset()`

### `tests/refute_golden_check.rs`
- uses:
  - `edgelord_lsp::refute::lsp_handler::{RefuteResponse, RefuteMeta, REFUTE_PROTOCOL_VERSION}`
  - `edgelord_lsp::refute::types::{BoundedList, RefuteLimits, DecisionInfo, JumpTarget, ByteSpan, StableAnchor, AnchorKind, TruncationReason}`
  - `edgelord_lsp::refute::witness::{Counterexample, CounterexamplePayload, FailureWitness, InterpretationSummary, InterpretationKind, DiagramBoundary}`
  - `edgelord_lsp::refute::probe::ProbeKey`
  - `edgelord_lsp::refute::slice::SliceSummary`
  - `edgelord_lsp::proposal::{Proposal, ProposalKind, ProposalStatus, EvidenceSummary}`
- items:
  - (priv fn) `fn test_manual_golden_json_strict()`

### `tests/refute_pipeline_integration.rs`
- uses:
  - `edgelord_lsp::refute::lsp_handler::{handle_refute_request, RefuteRequest, REFUTE_PROTOCOL_VERSION}`
- items:
  - (priv fn) `fn test_refute_pipeline_integration()`

### `tests/refute_tests.rs`

Golden determinism tests for refute endpoint (G5).

These tests lock the JSON schema and ensure byte-for-byte determinism.

- uses:
  - `edgelord_lsp::refute::witness::FailureWitness`
  - `edgelord_lsp::refute::types::RefuteLimits`
- items:
  - (priv fn) `fn test_refute_determinism_json_golden()` — Golden test: same input twice → identical JSON (G5)
  - (priv fn) `fn test_refute_level1_returns_missing_coherence_not_false()` — Golden test: coherence level 1 returns MissingCoherenceWitness, not equation failure (G4)
  - (priv fn) `fn test_lsp_refute_smoke()` — LSP smoke test: handler returns valid JSON, no Debug formatting (G1)
  - (priv fn) `fn test_refute_proposals_deterministic_ordering()` — Test deterministic ordering of proposals
  - (priv fn) `fn test_refute_json_schema_snapshot()` — Snapshot the golden JSON schema structure
  - (priv fn) `fn test_refute_slice_is_bounded_and_sorted()` — Slice bounded and sorted test (G2)

### `tests/selection_and_diagnostics.rs`
- uses:
  - `edgelord_lsp::document::{ByteSpan, ParsedDocument, selection_chain_is_well_formed}`
- items:
  - (priv fn) `fn selection_chain_expands_atom_list_form_root()`
  - (priv fn) `fn parse_error_produces_stable_diagnostic()`

### `tests/tactics_tests.rs`
- uses:
  - `edgelord_lsp::edgelord_pretty_ctx::EdgeLordPrettyCtx`
  - `edgelord_lsp::document::ParsedDocument`
  - `new_surface_syntax::proof_state::{ProofState, MetaSubst, ElaborationTrace}`
  - `tower_lsp::lsp_types::{Range, Position, Url}`
  - `std::sync::Arc`
- items:
  - (priv fn) `fn test_registry_compute_all()`
  - (priv fn) `fn test_add_touch_tactic_skips_if_exists()`
  - (priv fn) `fn test_focus_goal_tactic()`
