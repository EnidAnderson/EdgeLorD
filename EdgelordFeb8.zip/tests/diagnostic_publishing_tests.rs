// Property-Based Tests for Diagnostic Publishing
// Feature: regression-proof-contract
// Property 1: Canonical Pipeline Completeness
// Validates: Requirements 1.1, 1.2, 1.3

use edgelord_lsp::lsp::PublishDiagnosticsHandler;
use comrade_lisp::comrade_workspace::WorkspaceReport;
use comrade_lisp::{WorkspaceDiagnostic, WorkspaceDiagnosticSeverity};
use source_span::Span;
use tower_lsp::lsp_types::{DiagnosticSeverity, Url};
use std::collections::BTreeMap;

#[cfg(test)]
mod property_tests {
    use super::*;
    use proptest::prelude::*;

    // Strategy for generating diagnostic severities
    fn severity_strategy() -> impl Strategy<Value = WorkspaceDiagnosticSeverity> {
        prop_oneof![
            Just(WorkspaceDiagnosticSeverity::Error),
            Just(WorkspaceDiagnosticSeverity::Warning),
            Just(WorkspaceDiagnosticSeverity::Information),
        ]
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(100))]

        /// Property 1: Canonical Pipeline Completeness
        /// For any file elaboration with N errors, all N errors SHALL be collected through
        /// the canonical pipeline and published to LSP, never through intermediate paths.
        /// Validates: Requirements 1.1, 1.2, 1.3
        #[test]
        fn prop_canonical_pipeline_completeness(
            diagnostic_count in 1..100usize,
        ) {
            let text = "line1\nline2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10";
            let parsed_doc = edgelord_lsp::document::ParsedDocument::parse(text.to_string());
            
            // Create N diagnostics at different positions
            let diagnostics: Vec<WorkspaceDiagnostic> = (0..diagnostic_count)
                .map(|i| {
                    let offset = (i * 5) % text.len();
                    WorkspaceDiagnostic {
                        message: format!("error_{}", i),
                        span: Some(Span::new(offset, offset + 1)),
                        severity: WorkspaceDiagnosticSeverity::Error,
                        code: Some("ERR"),
                        notes: vec![],
                    }
                })
                .collect();

            let report = WorkspaceReport {
                diagnostics: diagnostics.clone(),
                diagnostics_by_file: BTreeMap::new(),
                structured_diagnostics: Vec::new(),
                fingerprint: None,
                revision: 0,
                bundle: None,
                proof_state: None,
            };

            let uri = Url::parse("file:///test.maclane").unwrap();
            
            // Convert through canonical pipeline
            let lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
                &uri,
                &report,
                &parsed_doc,
            );

            // PROPERTY: All N diagnostics must be published
            prop_assert_eq!(
                lsp_diagnostics.len(),
                diagnostic_count,
                "Canonical pipeline must publish all {} diagnostics, got {}",
                diagnostic_count,
                lsp_diagnostics.len()
            );

            // PROPERTY: No diagnostics should be lost or truncated
            for (i, lsp_diag) in lsp_diagnostics.iter().enumerate() {
                prop_assert!(
                    lsp_diag.severity.is_some(),
                    "Diagnostic {} missing severity (lost in pipeline)",
                    i
                );
                prop_assert!(
                    !lsp_diag.message.is_empty(),
                    "Diagnostic {} has empty message (corrupted in pipeline)",
                    i
                );
                prop_assert!(
                    lsp_diag.source.is_some(),
                    "Diagnostic {} missing source (lost in pipeline)",
                    i
                );
            }

            // PROPERTY: All diagnostics must be sorted deterministically
            for i in 1..lsp_diagnostics.len() {
                let prev = &lsp_diagnostics[i - 1];
                let curr = &lsp_diagnostics[i];
                
                // Verify ordering is maintained
                prop_assert!(
                    prev.range.start.line < curr.range.start.line ||
                    (prev.range.start.line == curr.range.start.line &&
                     prev.range.start.character <= curr.range.start.character),
                    "Diagnostics not properly sorted by position"
                );
            }
        }

        /// Property 15: Diagnostic Sorting Determinism
        /// For any unordered set of diagnostics, sorting should produce consistent results
        #[test]
        fn prop_diagnostic_sorting_determinism(
            count in 1..20usize,
        ) {
            let text = "hello world\nfoo bar\nbaz qux";
            let parsed_doc = edgelord_lsp::document::ParsedDocument::parse(text.to_string());
            
            // Create diagnostics with varying positions
            let diagnostics: Vec<WorkspaceDiagnostic> = (0..count)
                .map(|i| {
                    let offset = (i * 3) % text.len();
                    WorkspaceDiagnostic {
                        message: format!("msg_{}", i),
                        span: Some(Span::new(offset, offset + 1)),
                        severity: WorkspaceDiagnosticSeverity::Error,
                        code: Some("TEST"),
                        notes: vec![],
                    }
                })
                .collect();

            let report = WorkspaceReport {
                diagnostics,
                diagnostics_by_file: BTreeMap::new(),
                structured_diagnostics: Vec::new(),
                fingerprint: None,
                revision: 0,
                bundle: None,
                proof_state: None,
            };

            let uri = Url::parse("file:///test.txt").unwrap();
            
            // Convert and sort multiple times
            let first = PublishDiagnosticsHandler::convert_diagnostics(
                &uri,
                &report,
                &parsed_doc,
            );
            
            let second = PublishDiagnosticsHandler::convert_diagnostics(
                &uri,
                &report,
                &parsed_doc,
            );

            // Results should be identical
            prop_assert_eq!(first.len(), second.len());
            for (a, b) in first.iter().zip(second.iter()) {
                prop_assert_eq!(a.range, b.range);
                prop_assert_eq!(a.severity, b.severity);
                prop_assert_eq!(&a.message, &b.message);
            }
        }

        /// Property 10: LSP Integration Completeness
        /// For any file with N diagnostics, querying the LSP should return all N diagnostics
        /// Validates: Requirements 8.3, 8.5
        #[test]
        fn prop_lsp_integration_completeness(
            diagnostic_count in 1..50usize,
        ) {
            let text = "line1\nline2\nline3\nline4\nline5";
            let parsed_doc = edgelord_lsp::document::ParsedDocument::parse(text.to_string());
            
            // Create N diagnostics at different positions
            let diagnostics: Vec<WorkspaceDiagnostic> = (0..diagnostic_count)
                .map(|i| {
                    let offset = (i * 3) % text.len();
                    WorkspaceDiagnostic {
                        message: format!("diagnostic_{}", i),
                        span: Some(Span::new(offset, offset + 1)),
                        severity: if i % 2 == 0 {
                            WorkspaceDiagnosticSeverity::Error
                        } else {
                            WorkspaceDiagnosticSeverity::Warning
                        },
                        code: Some("D"),
                        notes: vec![],
                    }
                })
                .collect();

            let report = WorkspaceReport {
                diagnostics: diagnostics.clone(),
                diagnostics_by_file: BTreeMap::new(),
                structured_diagnostics: Vec::new(),
                fingerprint: None,
                revision: 0,
                bundle: None,
                proof_state: None,
            };

            let uri = Url::parse("file:///test.txt").unwrap();
            let lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
                &uri,
                &report,
                &parsed_doc,
            );

            // Verify all diagnostics were returned (not truncated)
            prop_assert_eq!(
                lsp_diagnostics.len(),
                diagnostic_count,
                "Expected {} diagnostics, got {}",
                diagnostic_count,
                lsp_diagnostics.len()
            );

            // Verify each diagnostic has required fields
            for (i, lsp_diag) in lsp_diagnostics.iter().enumerate() {
                prop_assert!(
                    lsp_diag.severity.is_some(),
                    "Diagnostic {} missing severity",
                    i
                );
                prop_assert!(
                    !lsp_diag.message.is_empty(),
                    "Diagnostic {} has empty message",
                    i
                );
                prop_assert!(
                    lsp_diag.source.is_some(),
                    "Diagnostic {} missing source",
                    i
                );
            }
        }
    }
}

#[cfg(test)]
mod unit_tests {
    use super::*;
    use edgelord_lsp::document::ParsedDocument;

    #[test]
    fn test_empty_diagnostics() {
        let text = "test";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        let report = WorkspaceReport {
            diagnostics: vec![],
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.txt").unwrap();
        let diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report,
            &parsed_doc,
        );

        assert_eq!(diagnostics.len(), 0);
    }

    #[test]
    fn test_diagnostic_with_code() {
        let text = "test";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        let diagnostic = WorkspaceDiagnostic {
            message: "test error".to_string(),
            span: Some(Span::new(0, 4)),
            severity: WorkspaceDiagnosticSeverity::Error,
            code: Some("E001"),
            notes: vec![],
        };

        let report = WorkspaceReport {
            diagnostics: vec![diagnostic],
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.txt").unwrap();
        let diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report,
            &parsed_doc,
        );

        assert_eq!(diagnostics.len(), 1);
        assert!(diagnostics[0].code.is_some());
    }

    #[test]
    fn test_diagnostic_source_field() {
        let text = "test";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        let diagnostic = WorkspaceDiagnostic {
            message: "test".to_string(),
            span: Some(Span::new(0, 4)),
            severity: WorkspaceDiagnosticSeverity::Error,
            code: None,
            notes: vec![],
        };

        let report = WorkspaceReport {
            diagnostics: vec![diagnostic],
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.txt").unwrap();
        let diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report,
            &parsed_doc,
        );

        assert_eq!(diagnostics.len(), 1);
        assert_eq!(diagnostics[0].source.as_deref(), Some("ComradeWorkspace"));
    }

    /// Integration test for LSP multi-diagnostic publication
    /// Validates: Requirements 8.3, 8.5
    #[test]
    fn test_lsp_multi_diagnostic_publication() {
        let text = "test content";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        
        // Create multiple diagnostics simulating a real elaboration scenario
        let diagnostics = vec![
            WorkspaceDiagnostic {
                message: "Unknown variable 'unknown_var'".to_string(),
                span: Some(Span::new(0, 4)),
                severity: WorkspaceDiagnosticSeverity::Error,
                code: Some("E001"),
                notes: vec![],
            },
            WorkspaceDiagnostic {
                message: "Type mismatch: expected i32, found error hole".to_string(),
                span: Some(Span::new(5, 12)),
                severity: WorkspaceDiagnosticSeverity::Error,
                code: Some("E002"),
                notes: vec![],
            },
            WorkspaceDiagnostic {
                message: "Unused variable 'y'".to_string(),
                span: Some(Span::new(1, 2)),
                severity: WorkspaceDiagnosticSeverity::Warning,
                code: Some("W001"),
                notes: vec![],
            },
        ];

        let report = WorkspaceReport {
            diagnostics,
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.maclane").unwrap();
        let lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report,
            &parsed_doc,
        );

        // Verify all workspace diagnostics are returned
        assert!(lsp_diagnostics.len() >= 3, "Expected at least 3 diagnostics, got {}", lsp_diagnostics.len());

        // Find the workspace diagnostics (they should be sorted by severity)
        let error_count = lsp_diagnostics.iter()
            .filter(|d| d.severity == Some(DiagnosticSeverity::ERROR))
            .count();
        let warning_count = lsp_diagnostics.iter()
            .filter(|d| d.severity == Some(DiagnosticSeverity::WARNING))
            .count();

        assert_eq!(error_count, 2, "Expected 2 errors");
        assert!(warning_count >= 1, "Expected at least 1 warning");

        // Verify each diagnostic has required fields
        for (i, diag) in lsp_diagnostics.iter().enumerate() {
            assert!(diag.severity.is_some(), "Diagnostic {} missing severity", i);
            assert!(!diag.message.is_empty(), "Diagnostic {} has empty message", i);
            assert!(diag.source.is_some(), "Diagnostic {} missing source", i);
        }

        // Verify diagnostic messages are preserved
        assert!(lsp_diagnostics.iter().any(|d| d.message.contains("Unknown variable")));
        assert!(lsp_diagnostics.iter().any(|d| d.message.contains("Type mismatch")));
        assert!(lsp_diagnostics.iter().any(|d| d.message.contains("Unused variable")));
    }

    /// Acceptance test: Determinism verification - same file elaborated multiple times
    /// Validates: Requirements 2.1, 10.2, 10.3
    #[test]
    fn test_acceptance_determinism_verification() {
        let text = "test content\nline 2\nline 3\nline 4\nline 5";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        
        // Create diagnostics
        let diagnostics: Vec<WorkspaceDiagnostic> = (0..10)
            .map(|i| {
                let offset = (i * 4) % text.len();
                WorkspaceDiagnostic {
                    message: format!("error_{}", i),
                    span: Some(Span::new(offset, offset + 1)),
                    severity: WorkspaceDiagnosticSeverity::Error,
                    code: Some("ERR"),
                    notes: vec![],
                }
            })
            .collect();

        let report = WorkspaceReport {
            diagnostics,
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.maclane").unwrap();
        
        // Convert 100 times and verify identical results
        let mut results = Vec::new();
        for _ in 0..100 {
            let lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
                &uri,
                &report,
                &parsed_doc,
            );
            results.push(lsp_diagnostics);
        }

        // All results should be identical
        for i in 1..results.len() {
            assert_eq!(
                results[0].len(),
                results[i].len(),
                "Diagnostic count differs at iteration {}",
                i
            );
            
            for (j, (diag0, diag_i)) in results[0].iter().zip(results[i].iter()).enumerate() {
                assert_eq!(
                    diag0.range, diag_i.range,
                    "Diagnostic {} range differs at iteration {}",
                    j, i
                );
                assert_eq!(
                    diag0.severity, diag_i.severity,
                    "Diagnostic {} severity differs at iteration {}",
                    j, i
                );
                assert_eq!(
                    &diag0.message, &diag_i.message,
                    "Diagnostic {} message differs at iteration {}",
                    j, i
                );
            }
        }
    }

    /// Integration test for error clearing through canonical pipeline
    /// Validates: Requirements 1.4
    #[test]
    fn test_error_clearing_through_canonical_pipeline() {
        let text = "test content";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        
        // Step 1: Create a report with errors
        let diagnostics_with_errors = vec![
            WorkspaceDiagnostic {
                message: "Error 1".to_string(),
                span: Some(Span::new(0, 4)),
                severity: WorkspaceDiagnosticSeverity::Error,
                code: Some("E001"),
                notes: vec![],
            },
            WorkspaceDiagnostic {
                message: "Error 2".to_string(),
                span: Some(Span::new(5, 12)),
                severity: WorkspaceDiagnosticSeverity::Error,
                code: Some("E002"),
                notes: vec![],
            },
        ];

        let report_with_errors = WorkspaceReport {
            diagnostics: diagnostics_with_errors,
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.maclane").unwrap();
        
        // Verify errors are published
        let lsp_diagnostics_with_errors = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report_with_errors,
            &parsed_doc,
        );
        assert_eq!(lsp_diagnostics_with_errors.len(), 2, "Expected 2 errors");

        // Step 2: Create a report with no errors (errors cleared)
        let report_cleared = WorkspaceReport {
            diagnostics: vec![],
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 1,
            bundle: None,
            proof_state: None,
        };

        // Verify errors are cleared
        let lsp_diagnostics_cleared = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report_cleared,
            &parsed_doc,
        );
        assert_eq!(lsp_diagnostics_cleared.len(), 0, "Expected 0 diagnostics after clearing");

        // Step 3: Verify clearing is deterministic
        let lsp_diagnostics_cleared_again = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &report_cleared,
            &parsed_doc,
        );
        assert_eq!(lsp_diagnostics_cleared_again.len(), 0, "Expected 0 diagnostics on re-check");
    }

    /// Property test for error clearing completeness
    /// For any error fixed, verify diagnostic is cleared through canonical pipeline
    /// Validates: Requirements 1.4
    #[test]
    fn test_prop_error_clearing_completeness() {
        let text = "test content\nline 2\nline 3";
        let parsed_doc = ParsedDocument::parse(text.to_string());
        
        // Create initial report with 5 errors
        let initial_diagnostics: Vec<WorkspaceDiagnostic> = (0..5)
            .map(|i| {
                let offset = (i * 3) % text.len();
                WorkspaceDiagnostic {
                    message: format!("error_{}", i),
                    span: Some(Span::new(offset, offset + 1)),
                    severity: WorkspaceDiagnosticSeverity::Error,
                    code: Some("ERR"),
                    notes: vec![],
                }
            })
            .collect();

        let initial_report = WorkspaceReport {
            diagnostics: initial_diagnostics.clone(),
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 0,
            bundle: None,
            proof_state: None,
        };

        let uri = Url::parse("file:///test.maclane").unwrap();
        
        // Verify all 5 errors are published
        let initial_lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &initial_report,
            &parsed_doc,
        );
        assert_eq!(initial_lsp_diagnostics.len(), 5, "Expected 5 initial errors");

        // Simulate fixing errors one by one
        for fixed_count in 1..=5 {
            // Create report with remaining errors
            let remaining_diagnostics: Vec<WorkspaceDiagnostic> = initial_diagnostics
                .iter()
                .take(5 - fixed_count)
                .cloned()
                .collect();

            let updated_report = WorkspaceReport {
                diagnostics: remaining_diagnostics,
                diagnostics_by_file: BTreeMap::new(),
                structured_diagnostics: Vec::new(),
                fingerprint: None,
                revision: fixed_count as u64,
                bundle: None,
                proof_state: None,
            };

            // Verify correct number of diagnostics remain
            let updated_lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
                &uri,
                &updated_report,
                &parsed_doc,
            );
            
            let expected_count = 5 - fixed_count;
            assert_eq!(
                updated_lsp_diagnostics.len(),
                expected_count,
                "Expected {} diagnostics after fixing {}, got {}",
                expected_count,
                fixed_count,
                updated_lsp_diagnostics.len()
            );
        }

        // Final check: all errors cleared
        let final_report = WorkspaceReport {
            diagnostics: vec![],
            diagnostics_by_file: BTreeMap::new(),
            structured_diagnostics: Vec::new(),
            fingerprint: None,
            revision: 5,
            bundle: None,
            proof_state: None,
        };

        let final_lsp_diagnostics = PublishDiagnosticsHandler::convert_diagnostics(
            &uri,
            &final_report,
            &parsed_doc,
        );
        assert_eq!(final_lsp_diagnostics.len(), 0, "Expected 0 diagnostics when all errors fixed");
    }
}
