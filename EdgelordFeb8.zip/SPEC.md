# Edgelord: Editor-Agnostic Interactive Theorem Proving via LSP

**Status:** Draft v0 (normative)

**Purpose:** Define a formal, editor-agnostic specification for **Edgelord**, an interactive theorem proving environment for the Mac Lane / Comrade Lisp surface syntax, delivered entirely through the **Language Server Protocol (LSP)**.

Edgelord treats **the proof artifact as the text file** and exposes interaction through LSP features (code actions, hovers, diagnostics, inlay hints, selection ranges). No bespoke GUI is required.

---

## 1. Conventions

* Normative keywords **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, **MAY** are to be interpreted as in RFC 2119.
* “Client” means an LSP-capable editor.
* “Server” means the Edgelord LSP server.

---

## 2. Goals and Non-Goals

### 2.1 Goals

1. **Editor agnostic:** Any LSP-compliant editor can serve as a fully functioning proofs-by-pointing ITP environment.
2. **Text is truth:** Proof state is derivable from the current workspace text + imports; interactive steps are applied as **workspace edits**.
3. **Structural editing:** Modern, lossless s-expression navigation/editing ("SLIME-class") expressed through LSP.
4. **Lens-based interaction:** Users point to subterms via cursor/selection; the server provides **targeted rewrites** and tactics as code actions.
5. **Deterministic semantics:** Given identical workspace contents, the server MUST produce identical compilation results, fingerprints, and ordered action lists.
6. **Coherence-aware rewrites:** Candidate rewrites are filtered to those valid under scope, typing/elaboration, and coherence constraints.

### 2.2 Non-Goals

1. Providing a custom GUI (although clients may optionally augment).
2. Requiring nonstandard editor extensions beyond LSP (server may optionally implement custom methods).
3. Specifying the full internal proof calculus of Mac Lane (this spec focuses on integration and interaction surfaces).

---

## 3. System Model

Edgelord consists of:

* **CST/AST layer** for Comrade Lisp (lossless parsing with spans).
* **Elaboration layer** mapping surface forms to core terms (e.g., `MorphismTerm`) with scope discipline.
* **Pattern graph + rewrite engine** producing candidate proof steps at a focus.
* **Lens reification** that converts semantic rewrites into minimal text patches.
* **LSP façade** that turns candidates into code actions and proof state into diagnostics/hovers/inlay hints.

### 3.1 Document Lifecycle

For each open document, the server maintains a **DocumentState** indexed by `uri` and `version`:

* `text`: current document text
* `cst`: lossless parse tree with spans
* `ast`: structured surface AST (if distinct)
* `anchors`: mapping between text ranges and stable anchors
* `elab`: elaboration result (core terms, environments, holes/goals)
* `index`: cross-file symbol/import index (workspace scope)
* `cache`: persistent memoization keyed by deterministic fingerprints

The server MUST treat `(uri, version)` as immutable; recomputation uses incremental update from `didChange`.

---

## 4. Terminology

### 4.1 Surface Terms

* **Form:** a top-level s-expression.
* **Touch:** declaration form introducing a symbol in scope.
* **Def:** definitional binding form requiring prior touch in scope.
* **Rule:** rewrite registration form.
* **Sugar/Macro:** pattern/template rewrite expansion (Comrade Lisp sugar).

### 4.2 Focus and Lens

* **Focus:** a user-selected subrange in a document representing a structural node.
* **Lens:** a function that maps a focus into an abstract “semantic view” and provides reification back to text edits.

---

## 5. Stable Anchors

Interactive operations must survive benign edits. Edgelord defines **Anchors**.

### 5.1 Anchor Definition

An **Anchor** is a stable identifier for a structural node:

* `path`: CST path (sequence of child indices from root)
* `local_hash`: a stable hash of the node’s canonical semantic content (when available)
* `kind`: node kind tag (atom/list/form/hole/…)

The server MUST be able to resolve an anchor to a current range in the newest version by:

1. Trying to follow `path` into the updated CST.
2. Validating with `kind` and `local_hash` (when present).
3. Falling back to best-effort nearest structural match if path mismatches.

### 5.2 Canonical Hash for Anchors

`local_hash` SHOULD be derived from the TCB-owned canonical bytes of the elaborated core term, when elaboration succeeds. When elaboration fails, the server MAY use a purely syntactic canonicalization of the CST node.

Anchors MUST NOT depend on memory addresses, insertion order of hash maps, or nondeterministic traversal.

---

## 6. Proof State Model

### 6.1 Holes and Goals

The surface syntax MUST include explicit holes (e.g., `?x` or `(hole x)`).

The elaboration layer produces:

* a list of **Goals** (holes requiring proof)
* each goal has:

  * `goal_id` (stable across recomputation where possible)
  * `range` (span in source)
  * `context` (bindings, assumptions)
  * `target` (type/proposition)

### 6.2 Diagnostics

The server MUST publish diagnostics for:

* parse errors
* scope discipline violations (e.g., `def` without `touch`)
* duplicate macro names (deterministic)
* duplicate definitions in a scope
* invalid rule metadata (e.g., metadata must be a non-empty list)
* unsolved goals (as informational or warning diagnostics)

Diagnostics MUST be stable in ordering and wording for a given document version.

---

## 7. Rewrite and Tactic Candidates

### 7.1 Candidate Interface

A **Candidate** represents an action applicable at a focus:

* `title`: short user-facing label
* `kind`: one of `rewrite`, `simp`, `normalize`, `expand`, `intro`, `apply`, `split`, `search`, `structural`
* `focus_anchor`: anchor targeted
* `preconditions`: machine-checkable requirements
* `result_preview`: optional short before/after snippet
* `edit_plan`: either a `WorkspaceEdit` or a server `Command` that yields edits
* `explanation`: structured text for hover/details

### 7.2 Validity

A candidate is **valid** only if:

1. Its preconditions hold in the current elaboration environment.
2. Applying it yields a well-formed surface program.
3. If it rewrites core terms, the rewrite is justified by an admissible rule/proof step under the current doctrine.

### 7.3 Deterministic Ordering

The server MUST order candidates deterministically by:

1. `kind` priority (configurable but fixed)
2. stable key of referenced rule/macro (canonical bytes hash)
3. lexicographic tie-breakers (title, range)

---

## 8. LSP Integration

Edgelord is implemented as an LSP server targeting LSP 3.17.

### 8.1 Required LSP Features

The server MUST implement:

* `initialize`, `initialized`, `shutdown`, `exit`
* `textDocument/didOpen`, `didChange`, `didClose`, `didSave`
* `textDocument/hover`
* `textDocument/codeAction`
* `textDocument/diagnostic` (or legacy `publishDiagnostics` flow)
* `textDocument/selectionRange`
* `textDocument/documentSymbol`

### 8.2 Recommended LSP Features

The server SHOULD implement when client supports:

* `textDocument/inlayHint` (goal/type display)
* `textDocument/semanticTokens` (structural coloring)
* `textDocument/definition` and `references` (jump-to-def)
* `workspace/symbol`
* `textDocument/formatting` (optional)
* `workspace/executeCommand` (for complex actions)

### 8.3 Capability Negotiation

On `initialize`, the server MUST inspect client capabilities and adapt:

* If `inlayHint` unsupported: provide equivalent info via hover.
* If `codeAction.resolve` unsupported: include full edits in code actions.
* If `executeCommand` unsupported: restrict to edits-only actions.

---

## 9. Method Semantics

### 9.1 `textDocument/selectionRange`

**Purpose:** structural selection expansion.

Given positions `p_i`, the server MUST return selection ranges that expand along CST parent links:

* atom → containing list → containing form → containing top-level

Ranges MUST align with whole s-expressions, not arbitrary character spans.

### 9.2 `textDocument/hover`

Hover at position `p` MUST provide, when available:

* inferred type / goal at `p`
* local context (bindings in scope)
* expanded macro view (optional)
* rule/macro documentation if `p` references a named entity

### 9.3 `textDocument/codeAction`

Given a range `r` (or cursor point), the server MUST:

1. Compute the best focus node(s) intersecting `r`.
2. Produce candidates across the following buckets:

   * structural edits (wrap/splice/raise/slurp/barf)
   * macro expansion actions
   * rewrite steps (rule-based)
   * normalization/simplification
   * goal-directed tactics (if a goal is focused)
3. Return CodeActions with either:

   * a `WorkspaceEdit`, or
   * a `Command` (for multi-step selection or expensive search)

Actions MUST be safe: applying them MUST keep the document parseable.

### 9.4 `workspace/executeCommand`

The server MAY expose commands for:

* tactic search with fuel / depth parameters
* e-graph bounded saturation previews
* interactive choice prompts (select lemma among many)

Commands MUST be deterministic for fixed inputs and workspace state.

### 9.5 Diagnostics

On each successful parse (even if elaboration fails), the server SHOULD publish structural errors.

On successful elaboration, the server MUST publish:

* scope/type errors
* goal diagnostics

---

## 10. Structural Editing (S-expression Operations)

Edgelord defines a core set of structural refactors as code actions. Each MUST be implemented as a CST-preserving edit.

### 10.1 Required Operations

* **Wrap with list**: `(wrap …)` around selection
* **Splice list**: remove list delimiters at focus
* **Raise**: replace parent with child
* **Slurp forward/backward**: pull adjacent sibling into current list
* **Barf forward/backward**: push last/first element out of current list
* **Transpose siblings**

### 10.2 Formatting Preservation

Edits MUST preserve comments and whitespace outside the affected ranges. Within the affected range, the server SHOULD preserve formatting when possible; otherwise it MAY reformat the smallest enclosing form.

---

## 11. Coherence-Aware Lens Reification

### 11.1 Reification Contract

Given a semantic transformation of a focused core term:

* Input: `(doc_version, focus_anchor, old_core_term, new_core_term)`
* Output: a minimal `WorkspaceEdit` that replaces the corresponding surface region with an updated surface term.

The server MUST ensure:

* the rewritten surface elaborates back to `new_core_term` (up to definitional equality)
* hygiene/scope constraints are preserved
* any introduced binders are accompanied by required `touch`/`def` forms per surface discipline

### 11.2 Coherence

If multiple surface renderings elaborate to the same core term, the server MUST choose a canonical rendering strategy (configurable but deterministic).

---

## 12. Imports and Workspace Indexing

### 12.1 Import Resolution

Import resolution MUST be deterministic and based solely on:

* workspace files
* explicit import forms
* configured search roots

The server MUST NOT depend on ambient OS state beyond configured roots.

### 12.2 Incrementality

Changes in a file MUST invalidate dependent elaborations and indexes transitively.

---

## 13. Determinism Requirements

For fixed workspace contents:

* elaboration output MUST be identical across runs
* candidate lists MUST be identical and identically ordered
* diagnostics MUST be identical
* fingerprints MUST be identical

The server MUST avoid nondeterminism from:

* hash map iteration order (use BTreeMap or sort keys)
* allocation-order-based IDs (use content-derived hashes)
* unstable error recovery paths

---

## 14. Extensibility

### 14.1 Custom Methods

Edgelord MAY define custom LSP methods under `edgelord/*` for:

* rich goal panels
* rewrite previews
* proof trace visualization

Clients that do not support these MUST still be fully usable via standard LSP features.

### 14.2 Tactic Plugins

The server MAY load tactic bundles as signed/verified artifacts. Any tactic plugin:

* MUST declare its inputs
* MUST be deterministic
* MUST not compromise the trusted kernel (Stonewall)

---

## 15. Security and Trust Boundaries

* The server MUST treat workspace text as untrusted input.
* The kernel verification (Stonewall/TCB) MUST remain the authority for:

  * canonical encoding
  * rule orientation
  * proof step validity (when applicable)

If the server provides “fast” speculative suggestions, it MUST re-check them before applying edits.

---

## 16. Compliance Test Suite

A conforming implementation SHOULD include:

1. **Golden LSP tests**: known `.comrade` files produce fixed diagnostics, hovers, and action lists.
2. **Round-trip tests**: applying any code action yields parseable text that re-elaborates to the predicted semantic result.
3. **Determinism tests**: repeated runs yield identical results.
4. **Structural edit tests**: selectionRange and structural operations preserve comments/whitespace outside range.

---

## Appendix A: Suggested Candidate Kinds and Priorities (v0)

Default priority order (highest to lowest):

1. Goal-directed local tactics (`intro`, `apply`, `split`)
2. Small rewrites (single lemma)
3. `simp` / `normalize` bounded
4. Macro expand/contract
5. Structural edits

This ordering MUST be stable for determinism.
